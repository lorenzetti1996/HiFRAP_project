#!/usr/bin/python
#IMPORT PACKAGES
###############################################################################################################################
###############################################################################################################################
import numpy as np
import random as rd
import scipy
from scipy import special
from scipy import optimize
import matplotlib.pyplot as plt
import time
from scipy.optimize import NonlinearConstraint,curve_fit
from csv import writer
import numpy as np
import random as rd
import scipy
from scipy import special
from scipy import optimize
import time
from scipy.optimize import NonlinearConstraint
from scipy.linalg import solve
from csv import writer
from scipy.fft import fft,ifft,fft2,ifft2
import pandas as pd
plt.figure(2)
#DEFINE USEFULL FUNCTIONS
###############################################################################################################################
###############################################################################################################################
#COMPUTE THE KERNEL MATRIX FOR FEW MODES
def compute_GGT_0_q_2D(D,g=0,alpha=0,nt=24,nx=100,DX=1,nqc=21):
	inqc=np.concatenate((np.arange(0,nqc//2+1,1),-np.arange(1,nqc//2+1,1)[::-1]))
	GGTq=np.zeros((nqc**2*(nt),nqc**2*(nt)))
	x=np.arange(0,nx,1)
	t=np.arange(0,2*nt,1)
	X,T=np.meshgrid(x,t)
	c=np.zeros((2*nt,nx))
	c[:,:]=np.exp(-(X*X)/(4*(D*T+DX*DX)))/np.sqrt(4*np.pi*(D*T+DX*DX))*np.exp(-g*T)
	inqc=(np.arange(1,nqc//2+1))
	x=np.arange(0,nx)
	q1=inqc/nx*np.pi*2
	q2=(q1[:])[::-1]
	X,Q1=np.meshgrid(x,q1)
	Y,Q2=np.meshgrid(x,q2)
	DCST=np.vstack((np.ones(nx)/np.sqrt(2),np.cos(Q1*X),np.sin(Q2*Y)))*np.sqrt(2)/np.sqrt(nx)
	X,Y=np.meshgrid(x,x)
	t=np.arange(0,nt,1)
	for i in range(0,len(t)):
		for j in range(0,len(t)):
			tau1=t[i]
			tau2=t[j]
			g=DCST@c[tau1+tau2,np.abs(X-Y)]@DCST.T
			GGTq[i*nqc**2:(i+1)*nqc**2,j*nqc**2:(j+1)*nqc**2]=np.transpose(np.outer(g,g).reshape(nqc,nqc,nqc,nqc),(0,2,1,3)).reshape(nqc*nqc,nqc*nqc)
 	
	return GGTq[:,:]

#COMPUTE THE COST FUNCTION
def objective(param,y,nqc,alpha):
	#SET THE PARAMETER
    D=param
    nt,nx,ny=y.shape
    nx=np.min((ny,nx))
    y=y[:,:nx,:nx]
    y=y.reshape(nt,nx**2)
    x=np.arange(0,nx)
	
	#FOURIER COMPRESSION
    inqc=(np.arange(1,nqc//2+1))
    q1=inqc/nx*np.pi*2
    q2=(q1[:])[::-1]
    X,Q1=np.meshgrid(x,q1)
    Y,Q2=np.meshgrid(x,q2)
    DCST=np.vstack((np.ones(nx)/np.sqrt(2),np.cos(Q1*X),np.sin(Q2*Y)))*np.sqrt(2)/np.sqrt(nx)
    DCST2=np.transpose(np.outer(DCST,DCST).reshape(nqc,nx,nqc,nx),(0,2,1,3)).reshape(nqc**2,nx**2)
    yq=np.zeros((nt,nqc**2))
    for t in range(0,nt):
        yq[t,:]=(DCST2@y[t,:])
    yq=yq.flatten()

    #COMPUTE GGT 
    Gq=compute_GGT_0_q_2D(D=D,nx=nx,nt=nt,nqc=nqc)  
    Gq=Gq.reshape(nt*nqc**2,nt*nqc**2)
    _,T1,T2,_=np.meshgrid(np.ones(nqc**2),np.arange(0,nt),np.arange(0,nt),np.ones(nqc**2))
    T1=T1.reshape(nt*nqc**2,nt*nqc**2)
    T2=T2.reshape(nt*nqc**2,nt*nqc**2)
    Gq=Gq*np.exp(-(alpha)*(T1+T2))

    #COMPUTE SVD
    u,s=np.linalg.svd(Gq,hermitian=True)[:2]
    lam=np.finfo(Gq.dtype).eps*len(Gq[:,0])*s[0]
	
	#COMPUTE THE FILTER

    F=lam/(s+lam)
    
	#COMPUTE THE PROJECTIO
    v1=np.outer(np.exp(-alpha*np.arange(0,nt)),np.concatenate(([1],np.zeros(nqc**2-1)))).flatten()
    C1=np.transpose(yq)@u@np.diag((F))@u.T@yq
    C2=np.transpose(yq)@u@np.diag((F))@u.T@v1
    C3=np.transpose(v1)@u@np.diag((F))@u.T@v1
    C=(C1-np.power(C2,2)/C3) /np.sum(F)
    plt.plot(D,C,"bo")
    return C



def initial_bound(y,nqc,alpha):
    Din=np.array([0,1,1e1,1e2,1e3,1e4])
    Cin=np.zeros(len(Din))
    for i in range(0,len(Din)):
        Cin[i]=objective(Din[i],y,nqc,alpha)

    j=np.argmin(Cin[:-1])
    if j<1:
        return (Din[0],Din[1])
    if j>4:
        return (Din[-3],Din[-1])
    else:
        return (Din[j-1],Din[j+1])


##########################################################################################################################
#COMPUTE THE ESTIMATED ERROR
def error_computation(param,ydata,nqc,alpha):
    #SET THE PARAMETERS
    res1=param
    Dopt=res1.x
    C=np.zeros(11)

    #COMPUTE THE OBJECTIVE
    Din=np.linspace(Dopt*0.95,Dopt*1.05,11)
    for i,D in enumerate(Din):
        C[i]=objective(D,ydata,nqc,alpha)
    # QUASRATIC FIT
    x = Din
    y = C
    A = np.column_stack((x**2, x, np.ones_like(x)))
    # Perform SVD
    U, S, Vt = np.linalg.svd(A, full_matrices=False)
    # Solve the system using SVD
    coefficients = Vt.T @ np.linalg.inv(np.diag(S)) @ U.T @ y
    # Extract coefficients for the quadratic fit
    a, b, c = coefficients
	# Generate the fitted quadratic curve
    C_fit = a * x**2 + b * x + c
    plt.figure(5)
    # Plot the data and the fitted quadratic curve
    plt.plot(Din, C, 'o', label='Data')
    plt.plot(Din, C_fit, label=f'Quadratic Fit: {a:.2f}D^2 + {b:.2f}D + {c:.2f}')
    plt.legend()
    plt.xlabel('D')
    plt.ylabel('Objective (C)')
    plt.title('Quadratic Fit with SVD')
    plt.savefig("output/quadraticfit.png")
    nt,nx,ny=ydata.shape
    nx=np.min((ny,nx))
    Gq=compute_GGT_0_q_2D(D=Dopt,nx=nx,nt=nt,nqc=nqc)
    Gq=Gq.reshape(nt*nqc**2,nt*nqc**2)
    u,s=np.linalg.svd(Gq,hermitian=True)[:2]
    lam=np.finfo(Gq.dtype).eps*len(Gq[:,0])*s[0]
    TrF=np.sum(lam/(lam+s))
    #1/np.sqrt(a)*np.sqrt(res1.fun/np.sqrt(TrF))
    return 1/np.sqrt(a)*np.sqrt(res1.fun)/np.sqrt(TrF)
 
 
##########################################################################################################################
#COMPUTE THE GOODNESS OF THE FIT
def pvalue_test(param,y,nqc,yp_std):
	#SET THE PARAMETERS
	D=param
	nt,nx,ny=y.shape
	nx=np.min((ny,nx))
	y=y[:,:nx,:nx]
	y=y.reshape(nt,nx**2)
	x=np.arange(0,nx)
	
	#FOURIER COMPRESSION
	inqc=(np.arange(1,nqc//2+1))
	q1=inqc/nx*np.pi*2
	q2=(q1[:])[::-1]
	X,Q1=np.meshgrid(x,q1)
	Y,Q2=np.meshgrid(x,q2)
	DCST=np.vstack((np.ones(nx)/np.sqrt(2),np.cos(Q1*X),np.sin(Q2*Y)))*np.sqrt(2)/np.sqrt(nx)
	DCST2=np.transpose(np.outer(DCST,DCST).reshape(nqc,nx,nqc,nx),(0,2,1,3)).reshape(nqc**2,nx**2)
	yq=np.zeros((nt,nqc**2))
	for t in range(0,nt):
		yq[t,:]=(DCST2@y[t,:])
	yq=yq.flatten()

    #COMPUTE GGT 
	Gq=compute_GGT_0_q_2D(D=D,nx=nx,nt=nt,nqc=nqc)  
	Gq=Gq.reshape(nt*nqc**2,nt*nqc**2)
	
    #COMPUTE SVD
	u,s=np.linalg.svd(Gq,hermitian=True)[:2]
	lam=np.finfo(Gq.dtype).eps*len(Gq[:,0])*s[0]
	
	#COMPUTE THE FILTER
	F=lam/(s+lam)
    
	#COMPUTE THE PROJECTION
	C=(np.transpose(yq)@u@np.diag((F))@u.T@yq)/np.sum(F)

	return 1-scipy.stats.chi2.cdf(C/n0_std**2*np.sum(F), np.sum(F))
 
 
##########################################################################################################################
#PLOT THE HALF RECOVERY CURVE
def curve_fit(y,s_maxi,D,alpha):
    nt,nx,ny=y.shape
    nx=np.min((ny,nx))
    y=y[:,:nx,:nx]
    y=y.reshape(nt,nx,nx)
    x=np.arange(0,nx)
    inqc=(np.arange(1,s_maxi//2+1))
    q1=inqc/nx*np.pi*2
    q2=(q1[:])[::-1]
    X,Q1=np.meshgrid(x,q1)
    Y,Q2=np.meshgrid(x,q2)
    DCST=np.vstack((np.ones(nx)/np.sqrt(2),np.cos(Q1*X),np.sin(Q2*Y)))*np.sqrt(2)/np.sqrt(nx)
    DCST2=np.transpose(np.outer(DCST,DCST).reshape(s_maxi,nx,s_maxi,nx),(0,2,1,3)).reshape(s_maxi**2,nx**2)
    yq=np.zeros((nt,s_maxi**2))
    for t in range(0,nt):
        yq[t,:]=DCST2@(y[t,:,:].flatten())
    yq=yq.flatten()
    nqc=s_maxi
    Gq=compute_GGT_0_q_2D(D=D,nx=nx,nt=nt,nqc=nqc)
    u,s,vt=np.linalg.svd(Gq,hermitian=True)
    r=np.finfo(Gq.dtype).eps*len(Gq[:,0])*s[0]	
	#COMPUTE THE FILTER
    lam=r
    F=lam/(s+lam)
    v1=np.outer(np.exp(-alpha*np.arange(0,nt)),np.concatenate(([1],np.zeros(nqc**2-1)))).flatten()
    C1=np.transpose(yq)@u@np.diag((F))@u.T@yq
    C2=np.transpose(yq)@u@np.diag((F))@u.T@v1
    C3=np.transpose(v1)@u@np.diag((F))@u.T@v1
    n0=C2/C3*v1
    yqfit=(u@np.diag(s/(lam+s))@u.T@(yq-n0))+n0
    #yqfit=(u@np.diag(s/(lam+s))@u.T@(yq))
    yqfit=yqfit.reshape(nt,s_maxi**2)
    yf=np.zeros((nt,nx*nx))
    yq=yq.reshape(nt,s_maxi**2)
    yf=np.zeros((nt,nx*nx))
    ycom=np.zeros((nt,nx*nx))
    for t in range(0,nt):
        yf[t,:]=(DCST2.T@yqfit[t,:])
        ycom[t,:]=(DCST2.T@yq[t,:])
    return yf.reshape(nt,nx,nx),ycom.reshape(nt,nx,nx)

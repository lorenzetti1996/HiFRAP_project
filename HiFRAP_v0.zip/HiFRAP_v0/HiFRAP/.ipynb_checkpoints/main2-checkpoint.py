#!/usr/bin/python

print("Hello World")

#IMPORT PACKAGES
import numpy as np
import random as rd
import scipy
from scipy import special
from scipy import optimize
import matplotlib.pyplot as plt
import time
from scipy.optimize import NonlinearConstraint,curve_fit
from csv import writer
import numpy as np
import random as rd
import scipy
from scipy import special
from scipy import optimize
import time
from scipy.optimize import NonlinearConstraint
from scipy.linalg import solve
from csv import writer
from scipy.fft import fft,ifft,fft2,ifft2
import pandas as pd
import functions as f

#INPUT PARAMETER
print("Hello World")

with open('input/parameters.txt', 'r') as file:
    data = file.read()
values = data.split(',')
print("Hello World")
# Assign values to variables
fframe = int(values[0])-1
pbleach = int(values[1])-1
lframe = int(values[2])-1
dimension = values[3]
model = values[4]
background = int(values[5])
controll = int(values[6])
nqc= int(values[7])


##########################################################
#INPUT DATA

#BACKGROUND
data = np.loadtxt("input/Background.txt")
print(data.shape)
df = pd.DataFrame(data, columns=["X", "Y", "t", "I"])
df = df[df["t"] < lframe]
yb=np.array(df ["I"])
bg=np.mean(yb)

#CONTROL
data = np.loadtxt("input/Control.txt")
df = pd.DataFrame(data, columns=["X", "Y", "t", "I"])
dfpost = df[(df["t"] >= pbleach) & (df["t"] < lframe)]
nt= len(dfpost['t'].unique())
nx = len(dfpost['X'].unique())
ny= len(dfpost['Y'].unique())

yc=np.array(dfpost["I"])
print(yc.shape)
print(nt*ny*nx)
yc=np.mean(yc.reshape(nt,ny*nx),1)

#TOTAL WINDOW
data = np.loadtxt("input/Frapped.txt")
df = pd.DataFrame(data, columns=["X", "Y", "t", "I"])
#prebleaching
dfpre = df[(df["t"] < pbleach)]
nt= len(dfpost['t'].unique())
nx = len(dfpost['X'].unique())
ny= len(dfpost['Y'].unique())
yp=np.array(dfpost["I"])
yp_mean,yp_std=np.mean(yp),np.std(yp)
#postbleaching
dfpost = df[(df["t"] >= pbleach) & (df["t"] < lframe)]
nt= len(dfpost['t'].unique())
nx = len(dfpost['X'].unique())
ny= len(dfpost['Y'].unique())
y=np.array(dfpost["I"])
y=y.reshape(nt,ny,nx)
dfpost = df[(df["t"] >= pbleach) & (df["t"] < lframe)]
nt= len(dfpost['t'].unique())
nx = len(dfpost['X'].unique())
ny= len(dfpost['Y'].unique())
y=np.array(dfpost["I"])
y=y.reshape(nt,ny,nx)
#########################################################################################

#NORMALISATION
####################################################################################
yc=yc-bg
yp=yp-bg
y=(y-bg)/yp_mean
####################################################################################

import numpy as np
from scipy.stats import linregress
import matplotlib.pyplot as plt

#FIT CONTROL AREA
####################################################################################
plt.figure(1)
def exponential_fit(x, a, b):
    return a * np.exp(-b * x)
# Assuming x represents the time points
x = np.arange(nt)
# Fit the data to the exponential function
# Apply logarithmic transformation
log_yc = np.log(yc)

# Perform linear regression on the transformed data
slope, intercept, r_value, p_value, std_err = linregress(x, log_yc)

# Exponentiate the intercept to get the original parameter 'a'
a_fit = np.exp(intercept)
b_fit = -slope
# Plot the original and fitted data
plt.scatter(x, yc, label='Original Data')
plt.plot(x, a_fit * np.exp(-b_fit * x), label=f'Exponential Fit (a={a_fit:.2f}, b=-{b_fit:.3f})')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
# Save the plot to a file (in PNG format, you can change the format if needed)
plt.savefig("output/control.png")

if b_fit>0:
	alpha=b_fit
else:
	alpha=0
for t in np.arange(0,nt):
    y[t,:,:]=y[t,:,:]-np.exp(-alpha*t)
###################################################################################


#PERFORM THE OPTIMISATION
a,b=f.initial_bound(y,nqc,alpha)
res1 = scipy.optimize.minimize_scalar(f.objective, args=(y,nqc,alpha), bounds=(a,b),method='bounded')
estimated_D = res1.x
estimated_error = f.error_computation(res1,y,nqc,alpha)
#pvalue = f.pvalue_test(res1.x,y,nqc)



#PRINT THE RESULTS
print("Estimated D =",res1.x)
print("Estimated error =",estimated_error)
#print("pvalue=",pvalue)

#SAVE THE RESULTS IN A TEXT FILE
with open("output/optimization_results.txt", "w") as file:
    file.write(f"Optimized D: {estimated_D}\n")
    file.write(f"Optimization Status: {res1.message}\n")
    file.write(f"Number of Function Evaluations: {res1.nfev}\n")

#PLOT THE COST FUNCTION
plt.figure(2)
#plt.xlim(estimated_D*0.5,estimated_D*1.5)
plt.savefig("output/Costfunction.png")
# You can also add more information to the text file as needed.

##############################################################################################################################



print("Hello World")
yf,ycom=f.curve_fit(y,nqc,estimated_D,alpha)


############ NO n0
plt.figure(3)
plt.imshow(np.mean(y,2),cmap="gray",aspect="auto")
plt.figure(4)
plt.imshow(np.mean(yf,2),cmap="gray",aspect="auto")
plt.show()
plt.figure(6)
plt.imshow(np.mean(ycom,2),cmap="gray",aspect="auto")
plt.show()
############################ with n0

plt.figure(7)
plt.title("with photobleahcing")
for t in np.arange(0,nt):
    y[t,:,:]=y[t,:,:]+np.exp(-alpha*t)
    yf[t,:,:]=yf[t,:,:]+np.exp(-alpha*t)

plt.imshow(np.mean(y,2),cmap="gray",aspect="auto")
plt.figure(8)
plt.title("with photobleaching")
plt.imshow(np.mean(yf,2),cmap="gray",aspect="auto")
plt.show()





//———————————————————————————————————————————————————————————————————————————–––
//
//
// HiFRAP
// Reference: Lorenzetti E, Munico-Diaz C, Minc N, Boudaoud A, Fruleux A
// "Inferring diffusion, reaction, and exchange parameters from imperfect FRAP"
//
//
//———————————————————————————————————————————————————————————————————————————–––
// 
// Fiji macro that wraps a Python code
// Auxilary files are saved in a temporary directory
// Results are saved in a .csv file
//
//———————————————————————————————————————————————————————————————————————————–––
//
//


//—————————————————————————
// DEFAULT PARAMETERS
//—————————————————————————


// do not change - directory containing main.py
var Apath = getDir("plugins")+"HiFRAP"+File.separator+"PyMacros"+File.separator;

// Image path
var Ipath = getDirectory("image") + getInfo("image.filename");
print("Image Path: " + Ipath);

// Get the last two directories for the exp name
parts = split(getDirectory("image"), File.separator);
n = lengthOf(parts);
if (n >= 2) {
    lastTwoDirs = parts[n-2] + "_" + parts[n-1];
} else if (n == 1) { //use just 1 directory if 
    lastTwoDirs = parts[0];
} else {
    lastTwoDirs = "(The image has no directories. Please put it in a directory)";
}




//extract default parameters from csv file
csvPath = getDirectory("plugins") + "HiFRAP" + File.separator + "Input" + File.separator +"params.csv";
csvContent = File.openAsString(csvPath);
if (lengthOf(csvContent) == 0) {
	//backup file if params is empty
	csvPath = getDirectory("plugins") + "HiFRAP" + File.separator + "Input"+ File.separator +"params0.csv";
	csvContent = File.openAsString(csvPath);
	}
// Split into lines
lines = split(csvContent, "\n");
// Assign variables
parts = split(lines[1], ","); EpathD = parts[1]; 
parts = split(lines[2], ","); RpathD = parts[1];	
parts = split(lines[3], ","); exD = parts[1];		
parts = split(lines[4], ","); modelD = parts[1];
parts = split(lines[5], ","); DD = parts[1];
parts = split(lines[6], ","); backD = parts[1];
parts = split(lines[7], ","); ctlD = parts[1];
parts = split(lines[8], ","); preD = parts[1];
parts = split(lines[9], ","); bleachD = parts[1];
parts = split(lines[10], ","); KStestD = parts[1];
parts = split(lines[11], ","); allGraphsD = parts[1];
parts = split(lines[12], ","); dxD = parts[1];
parts = split(lines[13], ","); dtD = parts[1];
parts = split(lines[14], ","); nqD = parts[1];
parts = split(lines[15], ","); thickD = parts[1];
parts = split(lines[16], ","); IpathD = parts[1];
parts = split(lines[17], ","); backcoordD = newArray(parts[1], parts[2], parts[3], parts[4]);
parts = split(lines[18], ","); ctlcoordD = newArray(parts[1], parts[2], parts[3], parts[4]);
parts = split(lines[19], ","); frapcoordD = newArray(parts[1], parts[2], parts[3], parts[4]);
parts = split(lines[20], ","); polyctrlxD = Array.slice(parts, 1, lengthOf(parts)); 
parts = split(lines[21], ","); polyctrlyD = Array.slice(parts, 1, lengthOf(parts)); 
parts = split(lines[22], ","); polyfrapxD = Array.slice(parts, 1, lengthOf(parts)); 
parts = split(lines[23], ","); polyfrapyD = Array.slice(parts, 1, lengthOf(parts)); 
parts = split(lines[24], ","); definparD = parts[1];
parts = split(lines[25], ","); DinparD = parts[1];
parts = split(lines[26], ","); betainparD = parts[1];
parts = split(lines[27], ","); varepsiloninparD = parts[1];



// Set default experimental name
if (IpathD == Ipath) {
    // Use the default value from the CSV file
    exD = exD;
} else {
    // Get the image title (without the extension)
    title = getTitle();
    // Remove the extension (e.g., .tiff, .tif)
    if (endsWith(title, ".tiff")) {
    titleWithoutExtension = substring(title, 0, lengthOf(title) - 5);
	} else if (endsWith(title, ".tif")) {
	    titleWithoutExtension = substring(title, 0, lengthOf(title) - 4);
	} else {
	    titleWithoutExtension = title; // No valid extension
	}
    
    // Build new experimental name using last two directories + image title without extension
    exD = lastTwoDirs + "_" + titleWithoutExtension;
}

// Get pixel size information from the image if present
//getPixelSize(unit, pixelWidth, pixelHeight, voxelDepth);
//if (unit != "pixels") {
//    dxD = pixelWidth;
//    unitD = unit;
//} else {
//    unitD="um";
//}
macro "HiFRAP" {

//—————————————————————————
// INITIALIZATION
//—————————————————————————


//do not show intermediary images
setBatchMode(true);



//check that a stack is open
if (nImages == 0)
	exit("A stack of images is required!");
else if (nSlices == 1)
	exit("A stack of images is required!");
ID = getImageID();


//—————————————————————————
// DEFINITION OF PARAMETERS
//—————————————————————————


// arrange dialog box according to default parameters
if (modelD == 1)
	modelchoice = newArray("diffusion [∂c/∂t=D∇²c]","reaction-diffusion [∂c/∂t=D∇²c+α-βc]","reaction [∂c/∂t=α-βc]");
if (modelD == 2)
	modelchoice = newArray("reaction-diffusion [∂c/∂t=D∇²c+α-βc]","diffusion [∂c/∂t=D∇²c]","reaction [∂c/∂t=α-βc]");
if (modelD == 3)
	modelchoice = newArray("reaction [∂c/∂t=α-βc]","reaction-diffusion [∂c/∂t=D∇²c+α-βc]","diffusion [∂c/∂t=D∇²c]");
if (DD == 1)
    Dchoice = newArray("1", "2");
	else Dchoice = newArray("2", "1");

if (backD == 1)
	backchoice = true;
	else backchoice = false;
if (ctlD == 1 && bleachD == 1)
	ctlchoice = true;
	else ctlchoice = false;
if (bleachD == 1)
	bleachchoice = true;
	else bleachchoice = false;
if (KStestD == 1)
	 KStestchoice = true;
	else  KStestchoice = false;
if (allGraphsD == 1)
	allGraphschoice = true;
	else allGraphschoice = false;


// box to define parameters
Dialog.create("HiFRAP: choice of parameters.");
Dialog.addMessage("The stack should correspond to a 2D time-lapse sequence.");
Dialog.addString("Location of anaconda HiFRAP enviroment",EpathD,25);
Dialog.addDirectory("Directory to save results",RpathD);
Dialog.addString("Experiment ID",exD,25);
Dialog.addChoice("Model", modelchoice); 
//Dialog.addToSameRow();
//Dialog.addMessage("   ∂c/∂t = D∇²c + α - βc ");
Dialog.addChoice("Dimension", Dchoice);
Dialog.addCheckbox("Background ROI exists", backchoice);
Dialog.addCheckbox("Imaging induces photobleaching", bleachchoice);
Dialog.addCheckbox("Estimate photobleaching from a control ROI", ctlchoice);
Dialog.addCheckbox("KS test (Warning: it could be very slow!)", KStestchoice)
Dialog.addCheckbox("Plot all the graphs (Warning: it could be slow!)", allGraphschoice);
Dialog.addCheckbox("Default initial minimisation starting point (set by the spatial-temporal window)", definparD);
Dialog.addNumber("Pixel size ", dxD, 4, 10, "um");
Dialog.addNumber("Time step ",dtD, 4, 10, "s");
Dialog.addNumber("Number of Fourier modes per axis",nqD);
Dialog.addNumber("First Frame #", 1);
Dialog.addNumber("First post bleach Frame #", 1+preD);
Dialog.addNumber("Last Frame #", nSlices);
Dialog.show();
Epath = Dialog.getString(); //enviroment path
Rpath = Dialog.getString();
ex = Dialog.getString();
modelT = Dialog.getChoice();
DT = Dialog.getChoice();
backT = Dialog.getCheckbox(); //var backT = 1 -> you need the background
bleachT = Dialog.getCheckbox();
ctlT = Dialog.getCheckbox();
KStestT = Dialog.getCheckbox();
allGraphsT = Dialog.getCheckbox();
definparT = Dialog.getCheckbox();
dx = Dialog.getNumber();
dt = Dialog.getNumber();
nq = Dialog.getNumber();
fframe = Dialog.getNumber();
pbframe = Dialog.getNumber();
lframe = Dialog.getNumber();

//find the correct python path
Ppath1 = Epath + File.separator + "bin" + File.separator +  "python";
Ppath2 = Epath  + File.separator + "bin" + File.separator +  "python3";
Ppath3 = Epath  + File.separator + "python.exe";
Ppath4 = Epath + File.separator + "python3.exe" ;
Ppath5 = Epath;
if (File.exists(Ppath1)) {
    Ppath = Ppath1;
} else if (File.exists(Ppath2)) {
    Ppath = Ppath2;
} else if (File.exists(Ppath3)) {
    Ppath = Ppath3;
} else if (File.exists(Ppath4)) {
    Ppath = Ppath4;
} else if (File.exists(Ppath5) && !File.isDirectory(Ppath5)) {
	Ppath = Ppath5;
    print("Warning: if -Welcome to python- is not printed, your python path "+ Ppath + " may be be wrong ");
} else {
    Ppath = "Not Found";
}

		

//tests of consistency
if (indexOf(Epath, " ") != -1) {
    exit("The enviroment path should not contain white space charaters");
} 
if (indexOf(Rpath, " ") != -1) {
    exit("The output directory path should not contain white space characters");
} 
if (indexOf(Ipath, " ") != -1) {
    exit("The image path should not contain white space characters");
} 
if (indexOf(ex, " ") != -1) {
   exit("The experimental name should not contain a white space character ");
} 
if (Ppath == "Not found")
	exit ("Python path not found. Check that the enviroment path on anaconda is correct or copy and paste the output of - import sys; print(sys.executable) - in the anaconda python console within HiFRAPenv enviroment");
//if ((D != 1) && (D != 2))
//	exit("Only 1- or 2-dimensional FRAP is allowed!"); 
if ((floor(fframe)!= fframe) || (floor(pbframe)!= pbframe) || (floor(lframe)!= lframe) || fframe == 0 || pbframe == 0 || lframe == 0)
	exit("The number of frames should be a positive integer!");
if (pbframe < fframe) 
	exit("Postbleach frame should be first frame or later frame!");
if (lframe < pbframe) 
	exit("Last frame should come after postbleach frame!");
if (fframe > nSlices || pbframe > nSlices || lframe > nSlices)
	exit("Frame # should be smaller than # of frames!");
if ((nq < 3) || (floor(nq)!= nq) || (nq % 2 == 0))
	exit("The number of modes should be an odd integer not smaller than 3!");


//conversions
if (modelT == "diffusion [∂c/∂t=D∇²c]")
	model = 1;
if (modelT == "reaction-diffusion [∂c/∂t=D∇²c+α-βc]")
	model=2;
if (modelT == "reaction [∂c/∂t=α-βc]")
	model=3;
if (DT == "1")
	D = 1 ;
	else D = 2;
if (backT) 
	back = 1;
	else back = 0;
if (ctlT) 
	ctl = 1;
	else ctl = 0;
if (pbframe == fframe) 
	pre=0; 
	else pre=1;
if (bleachT) 
	bleach = 1;
	else bleach = 0;
if (KStestT) 
	KStest = 1;
	else KStest = 0;
if (allGraphsT) 
	allGraphs = 1;
	else allGraphs = 0;
if (definparT) 
	definpar = 1;
	else definpar = 0;




//—————————————————————————
// INITIAL PARAMETER EXTRACTION
//—————————————————————————

if (definpar == 0) {
    Dialog.create("Set the intial parameters for the minimisation");

    if (model == 1 || model == 2) {
        Dialog.addNumber("Diffusion [D] ", DinparD,4,10,"um");
    }
    if (model == 2 || model == 3) {
        Dialog.addNumber("Exchange-rate [beta] ", betainparD,4,10,"s");
	}
    if (!(ctl == 1 || bleach == 0)) {
        Dialog.addNumber("Photobleaching decay-rate [varepsilon] ", varepsiloninparD,4,10, "[1]");
    }
	Dialog.addMessage("Suggestion: ");
	if (model == 1 || model == 2) Dialog.addMessage("D = L²/16T, with L the typical bleaching size and T the signal recovery time");
    if (model == 2 || model == 3) Dialog.addMessage("beta = log(2)/T, with T the typical signal recovery time");
    if (!(ctl == 1 || bleach == 0)) Dialog.addMessage("varepsilon = log(2)/NF, with NF the number of frames");
    Dialog.show();


    if (model == 1 || model == 2) 
    {
    	Dinpar = Dialog.getNumber();
    }
    else Dinpar = 0.0;

    if (model == 2 || model == 3) 
    {
    	betainpar = Dialog.getNumber();
    }
    else betainpar = 0.0;

    if (!(ctl == 1 || bleach == 0))
    {
    	varepsiloninpar = Dialog.getNumber();
    }
    else varepsiloninpar = 0.0;
}

else{
	Dinpar = 0.0;
	betainpar = 0.0;
	varepsiloninpar = 0.0;
}

	
//—————————————————————————
// DATA EXTRACTION
//——————————————————————
run("Select None");
// Prompt the user to draw a rectangle for the background
if (back == 1){
	selectImage(ID);
	setTool("rectangle");
	//if (IpathD == Ipath && backcoordD[0] != "nan") { //Draw a default rectangle from old selection
    setBatchMode(false); makeRectangle(backcoordD[0], backcoordD[1], backcoordD[2] - backcoordD[0], backcoordD[3] - backcoordD[1]); setBatchMode(true); 
	//}
	waitForUser("Background: Select a rectangle on the image and then press OK.");
	if (selectionType() != 0)
		exit("Rectangular selection needed!");
	getSelectionBounds(x1, y1, width, height);
	x2 = x1+width;
	y2 = y1+height;
	backcoord = ""+x1+","+y1+","+x2+","+y2;
	run("Select None");
}
else backcoord = "0,0,0,0"; //polyctrl = "0,0,0,0";


// Define thickness for linear selections 
if (D == 1){
	thick = getNumber("thickness of linear ROIs?",thickD);
	if ((floor(thick)!= thick) || (thick == 0) )
	exit("Thickness should be a positive integer!");
} else thick = 0;

// Prompt the user to draw the control area
if (ctl == 1){
	if (D == 1){
		selectImage(ID);
		setTool("polyline");
		//if (IpathD == Ipath){ //Perpare a default polyline 
		setBatchMode(false); makeSelection("polyline", polyctrlxD, polyctrlyD); setBatchMode(true);
		//}
		waitForUser("Control: Draw a segmented line on the image and then press OK.");
		if (selectionType() != 6)
			exit("Segmented line selection needed!");
		//save coordinates for the future analysis as default polyline
		getSelectionCoordinates(x, y);  
		polyctrlx = ""+x[0]; polyctrly = ""+y[0];
		for (i = 1; i < lengthOf(x); i++){
	    	 polyctrlx += "," + x[i] ;
	    	 polyctrly += "," + y[i];}
		run("Straighten...", "title=line.tif line="+thick+" process");
		run("Size...", "width=" + getWidth() + " height=1 depth=" + nSlices + " average");
		saveAs("Tiff", Rpath + "line_control.tif");}
	else {
	polyctrlx="0,0"; polyctrly="0,0";}
	
	if (D == 2){
		selectImage(ID);
		setTool("rectangle");
		//if (IpathD == Ipath && ctlcoordD[0] != "nan") {
    	setBatchMode(false); makeRectangle(ctlcoordD[0], ctlcoordD[1], ctlcoordD[2] - ctlcoordD[0], ctlcoordD[3] - ctlcoordD[1]); setBatchMode(true);
		//}
		waitForUser("Control: Select a rectangle on a unfrapped area and then press OK.");
		if (selectionType() != 0)
			exit("Rectangular selection needed!");
		getSelectionBounds(x1, y1, width, height);
		x2 = x1+width;
		y2 = y1+height;
		ctlcoord = ""+x1+","+y1+","+x2+","+y2;
		}
	else ctlcoord="0,0,0,0";
}	
else {
	ctlcoord="0,0,0,0"; polyctrlx="0,0"; polyctrly="0,0";
}
run("Select None");
// Prompt the user to draw the region surrounding the frapped area
if (D == 1){
	selectImage(ID);
	setTool("polyline");
	//if (IpathD == Ipath){ //Perpare a default polyline 
	setBatchMode(false); makeSelection("polyline", polyfrapxD, polyfrapyD); setBatchMode(true);
	//}
	waitForUser("Region surrounding FRAPped area: Draw a segmented line on the image and then press OK.");
	if (selectionType() != 6)
		exit("Segmented line selection needed!");
	//Save for future analysis
	getSelectionCoordinates(x, y);  
	polyfrapx = ""+ x[0]; polyfrapy = ""+ y[0];
	for (i = 1; i < lengthOf(x); i++) {
    	 polyfrapx += "," + x[i] ;
    	 polyfrapy += "," + y[i];}
   	//Build 1D time-lapse video
	run("Straighten...", "title=line.tif line="+thick+" process");
	run("Size...", "width=" + getWidth() + " height=1 depth=" + nSlices + " average");
	saveAs("Tiff", Rpath + "line_FRAP.tif");}
else {
polyfrapx="0,0"; polyfrapy="0,0";
}
if (D == 2){
	selectImage(ID);
	setTool("rectangle");
	//if (IpathD == Ipath && frapcoordD[0] != "nan") {
	setBatchMode(false); makeRectangle(frapcoordD[0], frapcoordD[1], frapcoordD[2] - frapcoordD[0], frapcoordD[3] - frapcoordD[1]); setBatchMode(true);
	//}
	waitForUser("Region surrounding FRAPped area: Select a square on the image by holding Shift and then press OK. ");
	if (selectionType() != 0)
		{
    	exit("Square selection needed!");
		}
	getSelectionBounds(x1, y1, width, height);
	if (width != height)
		{
    	exit("Selection is not a square! Hold Shift while drawing to ensure have a square.");
		}
	getSelectionBounds(x1, y1, width, height); 
	x2 = x1+width;
	y2 = y1+height;
	frapcoord = ""+x1+","+y1+","+x2+","+y2; run("Duplicate...", "duplicate");
}
else frapcoord="0,0,0,0";
run("Select None");

//—————————————————————————
// PYTHON CALL
//—————————————————————————
print("Analysis in progress...");
Pparam = ""+D+" "+back+" "+ctl+" "+bleach+" "+model+" "+fframe+ " "+pbframe + " "+ lframe + " "+ ex;
Pparam = Pparam + " "+backcoord+" "+ctlcoord+" "+frapcoord+" "+ polyctrlx+" "+ polyctrly + " "+polyfrapx+" "+polyfrapy +" "+ thick;
Pparam = Pparam + " "+ nq+" "+dt+" "+dx+" "+Ipath+" "+Rpath + " " + KStest +" " + allGraphs;
Pparam = Pparam + " " + definpar + " " + Dinpar + " " + betainpar + " " + varepsiloninpar;
print(Ppath+" "+Apath+"main.py "+Pparam);

start = getTime(); //time in millisecod
result = exec(Ppath+" "+Apath+"main.py "+Pparam);
end = getTime();
print(result);
duration = (end - start)/1000;
print("Execution time: " + duration + " s");
print("Result was saved.\n End.");


//SAVE THE DEFAULT PARAMETERS FOR THE NEXT USE OF HiFRAP
// Define the file path where parameters will be stored
var paramFile = getDirectory("plugins") + "HiFRAP" + File.separator + "Input" + File.separator + "params.csv";

// Open the file for writing (in write mode to overwrite any existing file)
var file = File.open(paramFile);  // "w" is write mode (will create or overwrite the file)

// Write the headers (column names)
print(file, "Parameter,Value");

// Write the parameters as CSV rows
print(file, "EpathD," + Epath);
print(file, "RpathD," + Rpath);
print(file, "exD," + ex);
print(file, "modelD," + model);
print(file, "DD," + D);
print(file, "backD," + back);
print(file, "ctlD," + ctl);
print(file, "preD," + pre);
print(file, "bleachD," + bleach);
print(file, "KStestD," + KStest);
print(file, "allGraphsD," + allGraphs);
print(file, "dxD," + dx);
print(file, "dtD," + dt);
print(file, "nqD," + nq);
print(file, "thickD," + thick);
print(file, "IpathD,"+Ipath);
print(file, "backcoordD, "+backcoord);
print(file, "ctlcoordD, "+ctlcoord);
print(file, "frapcoordD, "+frapcoord);
print(file, "polyctrlxD, "+polyctrlx);
print(file, "polyctrlyD, "+polyctrly);
print(file, "polyfrapxD, "+polyfrapx);
print(file, "polyfrapyD, "+polyfrapy);
print(file, "definpar,"+definpar);
print(file, "Dinpar,"+Dinpar);
print(file, "betainpar, "+betainpar);
print(file, "varepsilonapar, "+varepsiloninpar);


// Close the file after writing
File.close(file);

}
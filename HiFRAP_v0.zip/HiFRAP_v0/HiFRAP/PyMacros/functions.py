
####################################################################################################################################################
import random as rd
import scipy
from scipy import special
from scipy import optimize
import time
from scipy.optimize import NonlinearConstraint
from csv import writer
import numpy as np
import random as rd
import scipy
from scipy import special
from scipy import optimize
from scipy.special import erf
import time
from scipy.optimize import NonlinearConstraint
from csv import writer
import multiprocessing as mp
from scipy.special import erf
from opt_einsum import contract




####################################################################################################################################################

#compute the fourier compress matrix in 1D
def compress_matrix(nx,nqc):
    """
    nx: number of pixels
    nqc: number of fourier modes
    """
    inqc=(np.arange(1,nqc//2+1))
    x=np.arange(0,nx)
    q1=inqc/nx*np.pi*2
    q2=(q1[:])[::-1]
    X,Q1=np.meshgrid(x,q1)
    Y,Q2=np.meshgrid(x,q2)
    DCST=np.vstack((np.ones(nx)/np.sqrt(2),np.cos(Q1*X),np.sin(Q2*Y)))*np.sqrt(2)/np.sqrt(nx)

    return DCST

        
#COMPRESSION FOURIER
def fourier_compression(y,dim_y):#returns fourier 3D compression matrix nt x (nx^2)
    
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size  = dim_y
    
    #FOURIER COMPRESSION 1D
    DCST = compress_matrix(nx,nqc)
    if dimension == 1 :
        yq = contract("qx,tx->tq",DCST,y)


    #FOURIER COMPRESSION 2D 
    if dimension == 2 :
        yq = contract("qx,ky,txy->tqk",DCST,DCST,y)

    return yq

def from_fourier_to_realspace(yq,dim_y):
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size  = dim_y
   
    #FOURIER COMPRESSION
    DCST = compress_matrix(nx,nqc)
    

    if dimension == 1 :
        y = contract("qx,tq->tx",DCST,yq)

    if dimension == 2 :
        y = contract("qx,ky,tqk->txy",DCST,DCST,yq)

    return y



#compute the kernel for the simplified initial condition
def compute_GGT_0_q_2D_1stframe(D,beta=0,varepsilon=0,nt=24,nx=100,DX=1,nqc=21,dimension=2):
    """"
    D: diffusion 
    beta: exchannge rate
    varepsilon: photobleaching rate
    DX: PSF width
    nt: number of frames
    nx: number pf pixels per axis
    nqc: number of fourier modes per axis kept
    Unit: Time step = 1 Pixel size = 1 
    """

    
    #precompute repeatitive patterns (symmetry X1-X2 T1+T2)
    x=np.arange(0,nx,1)
    t=np.arange(0,2*nt,1)
    X,T=np.meshgrid(x,t)
    c=np.zeros((2*nt,nx))
    c[:,:]=np.exp(-(X*X)/(4*(D*T+DX*DX)))/np.sqrt(4*np.pi*(D*T+DX*DX))*np.exp(-(beta+varepsilon)/dimension*T) #the factor beta+varepsilon/dimension is beacuse is then computed in 2D
  
   
    #compress the matrix in 1D, then compute the kernel in 2D
    DCST=compress_matrix(nx,nqc)
    X,Y=np.meshgrid(x,x)
    t=np.arange(0,nt,1)
    
    #compress the matrix in 1D
    if dimension == 1:
        Gq=np.zeros((nqc*nt,nqc)) 
        for i in range(0,len(t)):
            tau1=t[i]
            gq=DCST@c[tau1,np.abs(X-Y)]@DCST.T
            Gq[i*nqc:(i+1)*nqc,:]=gq

    #compress the matrix in 1D, then compute the kernel in 2D
    if dimension == 2: 
        Gq=np.zeros((nqc**2*nt,nqc**2))
        for i in range(0,len(t)):
            tau1=t[i]
            gq=DCST@c[tau1,np.abs(X-Y)]@DCST.T
            Gq[i*nqc**2:(i+1)*nqc**2,:]=np.transpose(np.outer(gq,gq).reshape(nqc,nqc,nqc,nqc),(0,2,1,3)).reshape(nqc*nqc,nqc*nqc)

    return  Gq




#compute the kernel in the fourier for 1 axis 
def compute_GGT_0_q_1D_henkel_tensor(D,beta=0,varepsilon=0,nt=24,nx=100,DX=1,nqc=21,dimension=2):
    """
    D: diffusion 
    beta: exchannge rate
    varepsilon: photobleaching rate
    DX: PSF width
    nt: number of frames
    nx: number pf pixels
    nqc: number of fourier modes
    Unit: Time step = 1 Pixel size = 1 
    """


    #COMPUTE THE UNIQUE PART OF THE KERNEL IN THE REAL SPACE (SYMMETRY X1-X2 T1+T2)
    x=np.arange(0,nx,1)
    t=np.arange(0,2*nt,1)
    X,T=np.meshgrid(x,t)
    c=np.zeros((2*nt,nx))
    c[:,:]=np.exp(-(X*X)/(4*(D*T+DX*DX)))/np.sqrt(4*np.pi*(D*T+DX*DX))*np.exp(-(beta+varepsilon)/dimension*T)  #the factor beta+varepsilon/dimension is beacuse is then computed in 2D

    #COMPUTE THE COMPRESS MATRIX IN SPACE
    DCST = compress_matrix(nx,nqc)
    
    
    #compute the compressed Hankel block (symmetry T1+T2)
    X,Y=np.meshgrid(x,x)
    DXY = np.abs(X-Y)
    t=np.arange(0,nt,1)
    abs_diff = np.abs(X - Y)  
    H = []
    for i in range(2*nt-1):
        gq = DCST @ c[i, DXY] @ DCST.T
        H.append((gq.reshape(nqc, nqc))) 
    
    
    #COMPUTE THE FULL MATRIX
    GGTq = np.zeros((nt,nqc,nt,nqc))
    for i in range(0,nt):
        for j in range(0,nt):
            # Compute the whole matrix
            GGTq[i,:,j,:] = H[i+j]


    return  GGTq


#compute the inverse of a choleski matrix 
def inverse_from_cholesky_matrix_lapack(A):
    # Compute the Cholesky factor L using LAPACK's DPOTRF
    L, info = scipy.linalg.lapack.dpotrf(A, lower=True)
    if info != 0:
        raise ValueError("Cholesky decomposition failed with info code:", info)
    
    # Compute the inverse of L using LAPACK's DTRTRI
    Linv, info = scipy.linalg.lapack.dtrtri(L, lower=True, unitdiag=False)
    if info != 0:
        raise ValueError("Triangular matrix inversion failed with info code:", info)
  
    
    return Linv

def compute_pseudo_inverse_choleski(A,tol):
    s0 = scipy.sparse.linalg.svds(A,k=1,return_singular_vectors=False) 
    lam=s0*tol
    Linv = inverse_from_cholesky_matrix_lapack(A+lam*np.eye(A.shape[0]))
    return lam , Linv

#Compute the Shift vector ALREADY COMPRESSED with Sin Cos matrix (change if you use another compression)
def compute_h_alpha(beta,varepsilon,yq,dim_y):
    
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    if dimension == 2:
        if np.abs(beta)>1e-7:
            h = np.outer(np.array((1-np.exp(-beta*np.arange(0,nt,1)))/beta*np.exp(-varepsilon*np.arange(0,nt,1))),np.concatenate(([nx],np.zeros(nqc**2-1)))).flatten()  
        else:
            h = np.outer(np.array(np.arange(0,nt,1))*np.exp(-varepsilon*np.arange(0,nt,1)),np.concatenate(([nx],np.zeros(nqc**2-1)))).flatten()
        h = h.reshape(nt,nqc,nqc)

    if dimension == 1:
        if np.abs(beta)>1e-7:
            h=np.outer(np.array((1-np.exp(-beta*np.arange(0,nt,1)))/beta*np.exp(-varepsilon*np.arange(0,nt,1))),np.concatenate(([np.sqrt(nx)],np.zeros(nqc-1)))).flatten()  
        else:
            h=np.outer(np.array(np.arange(0,nt,1))*np.exp(-varepsilon*np.arange(0,nt,1)),np.concatenate(([np.sqrt(nx)],np.zeros(nqc-1)))).flatten()
        h = h.reshape(nt,nqc)

    return h


#Compute the Shift vector ALREADY COMPRESSED with Sin Cos matrix (change if you use another compression)
def compute_h0(varepsilon,yq,dim_y):
    
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    if dimension == 2:
        h = np.outer(np.exp(-varepsilon*np.arange(0,nt,1)),np.concatenate(([nx],np.zeros(nqc**2-1)))).flatten()  
        h = h.reshape(nt,nqc,nqc)

    if dimension == 1:
        h=np.outer(np.exp(-varepsilon*np.arange(0,nt,1)),np.concatenate(([np.sqrt(nx)],np.zeros(nqc-1)))).flatten()   
        h = h.reshape(nt,nqc)

    return h

#Compute the Shift vector ALREADY COMPRESSED with Sin Cos matrix (change if you use another compression)
def compute_h_bg(varepsilon,yq,dim_y):
    
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    if dimension == 2:
        h = np.outer(np.ones(nt),np.concatenate(([nx],np.zeros(nqc**2-1)))).flatten()  
        h = h.reshape(nt,nqc,nqc)

    if dimension == 1:
        h=np.outer(np.ones(nt),np.concatenate(([np.sqrt(nx)],np.zeros(nqc-1)))).flatten()   
        h = h.reshape(nt,nqc)

    if prebleaching > 0 and photobleaching != 0 and back==0: #the only case in which cs-->Itot and shift term for the back. is 1-e^{-vareppilin/dt t}
        h = h - compute_h0(varepsilon,yq,dim_y)
    
    return h

#compute the residuals from the kernel inverted matrix
def project_residuals(K_inv,yq, dim_y,lam = 0):
    
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    if dimension == 1: #if dimension = 1 r_i = lam (K+lam )^{-1} Y = lam@Linv.T@Linv@yq
        residuals = (lam * K_inv @ (yq.flatten())).reshape(nt,nqc)

    if dimension == 2: #we worked with the reduced kernel 
        U,K_red_inv=K_inv
        n_k = np.int16(np.sqrt(K_red_inv.shape[0])) 
        #FINAL RESIDUALS FUNCTION LL^T 
        x = contract('ijk,ilm,ijl->km ',U,U,yq).flatten()
        x = np.dot(K_red_inv,x).reshape(n_k,n_k)
        residuals = yq - contract('ijk,ilm,km->ijl ',U,U,x)


    return residuals



#compute the source rate from the kernel inverted matrix
def compute_alpha(J_alpha,residual):
    C2 = -(residual.flatten())@(J_alpha.flatten())
    C3 = (J_alpha.flatten())@(J_alpha.flatten())
    alpha = C2/C3 
    return alpha

def compute_bg(J_bg,residual):
    C2 = -(residual.flatten())@(J_bg.flatten())
    C3 = (J_bg.flatten())@(J_bg.flatten())
    bg = C2/C3 
    return bg

def compute_bg_alpha(J_bg,J_alpha,residual):
    PG = - np.vstack((J_bg.flatten(),J_alpha.flatten())).T
    bg,alpha = np.linalg.inv(contract('ij,ik->jk',PG,PG)) @ np.dot(PG.T,residual.flatten())
    return bg,alpha




#reduce the kernel K = Gq_x Gqy_y by SVD truncation along each axis such that K \approx M_x M_y, where M_x = U_r sigma_r Vt_r. Output: n_k (number of modes), U and (M_x M_y).T@(M_x M_y).T
def kernel_reduction(Gq,dim_y):
    
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 
    
    u,s,ut = np.linalg.svd(Gq.reshape(nqc*nt,nqc*nt),hermitian ="True")
    lam = s[0] * Gq.shape[0] *  Gq.shape[1] * np.finfo(Gq.dtype).eps
    s = s[s>lam]
    n_k = len(s)
    u = u[:,:n_k]
    

    #COMPUTING THE MATRIX MtM TO SOLVE THE LINEAR PROBLEM
    t1 = np.arange(0,nt).reshape(-1,1,1)
    qx = np.arange(0,nqc).reshape(1,-1,1)
    k = np.arange(0,n_k).reshape(1,1,-1)
    U = u[t1*nqc+qx,k]*np.sqrt(s[k])

    return n_k,U


####################################################################################
####################################################################################
def residuals_1stframe(D,beta,varepsilon,bg,cs,yq,dim_y):
    """                     
    D: diffusion coefficient
    beta: loss rate
    varepsilon: photobleaching loss rate per frame
    bg: background value if known
    cs: stationary concentration when back and prebleaching is known or Itot when the background is not known
    yq: data vector 
    dim_y: list containing the dimenson of the system, number of prebleaching frames, nt (number of frames), nx (number of pixels per axis) and nqc (number of fourier modes per axis), time step and pixel size
    varepsilon: photobleaching rate
    """
    

    yq = yq.flatten()
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size  = dim_y

    Gq = compute_GGT_0_q_2D_1stframe(D=D,beta=beta,varepsilon=varepsilon,nx=nx,nt=nt,nqc=nqc,dimension=dimension)
    #invert the kernel 
    Kinv = np.linalg.inv(Gq.T@Gq)


    h0  = compute_h_alpha(beta,varepsilon,yq,dim_y).flatten()
    h_bg  = compute_h_bg(varepsilon,yq,dim_y).flatten() 

    #compute the final residuals
    yqfit = Gq@(Kinv@(Gq.T@yq))
    residual = yq - yqfit
    
    J_bg = h_bg-Gq@(Kinv@(Gq.T@h_bg))
    J_cs = h0-Gq@(Kinv@(Gq.T@h0))

    PG = - np.vstack((J_bg.flatten(),J_cs.flatten())).T
        
    bg,cs = np.linalg.inv(contract('ij,ik->jk',PG,PG)) @ np.dot(PG.T,residual.flatten())

    
    residuals = residual + bg * J_bg + cs * J_cs



    return residuals

####################
#####################

#compute the residuals inverting the kernel matrix (a SVD precompression is applied in 1D)
def residuals_reduced_K_full_lapack(D,beta,varepsilon,bg0,cs,yq,dim_y,return_all=False,implicit=True,bg=np.nan,alpha=np.nan):
    """
    D: diffusion coefficient
    beta: loss rate
    varepsilon: photobleaching loss rate per frame
    bg0: background value if known
    cs: stationary concentration when back and prebleaching is known or Itot when the background is not known
    yq: data vector 
    dim_y: list containing the dimenson of the system, number of prebleaching frames, nt (number of frames), nx (number of pixels per axis) and nqc (number of fourier modes per axis), time step and pixel size
    varepsilon: photobleaching rate
    return_trace: if true return also the trace, i.e. the effective degrees of freedom 
    implicit : if true, when the background or cs is not known they are implited estimated from data; if false background and alpha needed as input
    bg: background value wheb implicit==True
    alpha: source rate when implicit==True

    """
    
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    #CONSTRUCTING THE KERNEL MATRIX IN 1 DIMENSION
    Gq=compute_GGT_0_q_1D_henkel_tensor(D=D,beta=beta,varepsilon=varepsilon,nx=nx,nt=nt,nqc=nqc,dimension=dimension) #Gq[t1,q1,t2,q2]
    
        
    if dimension == 2: #REDUCE THE KERNEL OF THE MATRIX 
        n_k,U = kernel_reduction(Gq,dim_y)
        S = contract("ijk,ijm->ikm", U,U)
        MtM = contract("iab,icd->acbd", S,S).reshape(n_k**2,n_k**2) #reduced kernel to invert


    #COMPUTING THE PSEUDOINVERSE WITH THE THE CHOLESKI DECOMPOSITION
    if dimension == 1: 
        lam,Linv = compute_pseudo_inverse_choleski(Gq.reshape(nqc*nt,nqc*nt),tol=nt*nqc*np.finfo(Gq.dtype).eps)
        K_inv = contract('lk,li->ki',Linv,Linv)
        #Compute the trace of the inverse matrix
        inv_tr = np.sum(K_inv**2)
        TrF  = np.squeeze(lam**2 * inv_tr) 


    if dimension == 2:
        lam,Linv = compute_pseudo_inverse_choleski(MtM,tol=nqc**2*nt*np.finfo(MtM.dtype).eps)
        K_red_inv = contract('lk,li->ki',Linv,Linv) #K_red_inv is K reduced
        inv_tr = np.sum(K_red_inv**2)
        TrF  = (lam**2 * inv_tr + nqc**2*nt - n_k**2)
        K_inv = U,K_red_inv


    #substract the background if background is known
    if back==1 and (photobleaching!=0 or model!=1): #do not do it when there the background fit is not defined , i.e. when photobleaching=0. 
        yq = yq - bg0 * compute_h_bg(varepsilon,yq,dim_y)

    #substract the homogeneous term if control is known
    if (model == 2 or model == 3):
        if prebleaching > 0:
            yq = yq -  cs * compute_h0(varepsilon,yq,dim_y)    
    #compute residuals with no shift (not normalised with the trace)
    residual = project_residuals(K_inv,yq,dim_y,lam)

    #Default values
    bg_est = np.nan
    alpha_est = np.nan
    J_alpha = np.array([np.nan])
    J_bg = np.array([np.nan]) 
    
    #compute the Jacobian for the background
    if back == 0 and photobleaching != 0:   
        h_bg = compute_h_bg(varepsilon,yq,dim_y)  
        J_bg = - project_residuals(K_inv,h_bg,dim_y,lam) #compute the jacobian with respect to the source rate


    #compute the Jacobian for the source rate 
    if (model==2 or model==3) and prebleaching < 1 :
        h_alpha = compute_h_alpha(beta,varepsilon,yq,dim_y)  
        J_alpha = - project_residuals(K_inv,h_alpha,dim_y,lam) #compute the jacobian with respect to the source rate


    #estimate and marginalise the background/source rate
    if not np.isnan(J_bg).any():
        if not np.isnan(J_alpha).any(): 
            if implicit == True:
                bg_est,alpha_est = compute_bg_alpha(J_bg, J_alpha,residual)
                bg = bg_est
                alpha = alpha_est
            residual = residual + J_alpha * alpha  + J_bg * bg
        else:
            if implicit==True:
                bg_est = compute_bg(J_bg,residual)
                bg = bg_est
            residual = residual  + J_bg * bg  


    else: 
        if not np.isnan(J_alpha).any():
            
            if implicit == True: 
                alpha_est = compute_alpha(J_alpha,residual)
                alpha = alpha_est

            residual = residual + J_alpha * alpha



    #Normalise the residuals and the Jacobian with the trace
    residual = residual / np.sqrt(TrF)
    J_alpha = J_alpha / np.sqrt(TrF)
    J_bg = J_bg / np.sqrt(TrF)

    if return_all == False:
        return residual.flatten()
    else:
        return residual,np.sum(residual**2),np.squeeze(TrF),bg_est,alpha_est,J_bg.flatten(),J_alpha.flatten()  #the jacobian are expected as 1d vector

####################################################################################
####################################################################################

#COMPUTE THE ESTIMATED ERROR
def compute_error(J,C,TrF):
    Hess = np.dot(J.T,J)
    
    if np.isscalar(Hess):
        covM = 1/Hess*C/TrF
        err = np.sqrt(np.diag((1/Hess*C/TrF)))
    else:
        covM = np.linalg.pinv(Hess)*C/TrF
        err = np.sqrt(np.diag((np.linalg.pinv(Hess)*C/TrF))) #approximated error from the Jacobian
    
    output = [*err,covM]
    return output


#COMPUTE THE GOODNESS OF THE FIT
def kolmogorov_test(D,beta,alpha,varepsilon,bg,cs,yq,dim_y):


    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    

    #CONSTRUCTING THE KERNEL MATRIX IN 1 DIMENSION
    ####################################################
    Gq=compute_GGT_0_q_1D_henkel_tensor(D=D,beta=beta,varepsilon=varepsilon,nx=nx,nt=nt,nqc=nqc) #Gq[t1,t2,nqc,nqc]
    
    
    #transform the tensor into a 2-D matrix
    if dimension==1:
        Gq = Gq.reshape(nt*nqc,nt*nqc)
    
    #COMPUTING THE M TO SOLVE THE LINEAR PROBLEM
    if dimension == 2: #REDUCE THE KERNEL OF THE MATRIX 
        n_k,U = kernel_reduction(Gq,dim_y)
        M = contract('txk,tym->txykm',U,U)
        Gq = M.reshape(nt*nqc**2,n_k**2) #Gq gets the reduced kernel 
    
    #Compute the eigenmodes
    u,s,vt=np.linalg.svd(Gq)                                                                                                                
    
    #COMPUTED THE REDUCED RESIDUALS WITH A SHARP FILTER
    lam = s[0] * Gq.shape[0] * np.finfo(Gq.dtype).eps
    s = s[s>lam]
    n_k = len(s)
    u = u[:,n_k:]
    
    
    

    #substract the homogeneous term due to the background  
    if photobleaching != 0 or (model!=1 and back == 1):
        yq = yq - bg * compute_h_bg(varepsilon,yq,dim_y)



    #substract the homogeneous term due to the source rate 
    if (model==2 or model==3):
        if prebleaching > 0:
            yq = yq - cs * compute_h0(varepsilon,yq,dim_y)
        else:
            yq = yq - alpha * compute_h_alpha(beta,varepsilon,yq,dim_y)


    
    residuals=u.T@yq.flatten() #uncorrelated residuals
    stat, kol_pvalue = scipy.stats.kstest(residuals[:], 'norm',args=(0,np.std(residuals)))
                                                                                                    
    

    return kol_pvalue




def compute_initial_guess(y,dim_y,compute_D = True, compute_beta = True, compute_varepsilon = True):
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    L_approx = nx/2
    T = (nt-1)/2
    
    initial_guess = []
    if compute_D == True :
        if dimension ==2:
            Din = L_approx**2 / T / 16  
        if dimension ==1:
            Din = L_approx**2 /T / 8
        initial_guess.append(Din)
    if compute_beta  == True :
        betain = np.log(2)/T
        initial_guess.append(betain)
    if compute_varepsilon == True:
        varepsilonin = np.log(2)/T
        initial_guess.append(varepsilonin)
    
    return np.array(initial_guess)

def compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta):
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    if dimension == 2:
         yq0 = yq.copy(); yq0[:,0,0] -= np.mean(yq[:,0,0]); R_2 = 1 - (Cmin * TrF / (TrF - n_theta)) / np.sum(yq0**2/(yq0.size-1))
    if dimension == 1:
         yq0 = yq.copy(); yq0[:,0] -= np.mean(yq[:,0]); R_2 = 1 - (Cmin * TrF / (TrF - n_theta)) / np.sum(yq0**2/(yq0.size-1))

    return R_2


"""
The objective of this script is to collect the input parameters from the Fiji macro, including the importion the raw signal value from the tiff file.
Next, the preprocessing of the raw input signal is performed in preprocessing.py
Then, HiFRAP inference analysis is computed in optimisation.py 
The output results are passed back to this script and saved in a csv file

"""



print("Welcome to python")
#IMPORT PACKAGES
import numpy as np
import random as rd
import scipy
from scipy import special
from scipy.special import erf
from scipy import optimize
import matplotlib.pyplot as plt
import time
from scipy.optimize import curve_fit
from csv import writer
import matplotlib.pyplot as plt
import numpy as np
import random as rd
import scipy
from scipy import special
from scipy import optimize
import time
from scipy.linalg import solve
from csv import writer
from scipy.fft import fft,ifft,fft2,ifft2
import pandas as pd
import tifffile
from tifffile import imread 
import matplotlib.gridspec as gridspec
import functions as f
import plot_results
import preprocessing 
import optimisation
import matplotlib.gridspec as gridspec
import sys
import os 
import csv

#tiff_file_path = "Sample.tif"



# Check if the correct number of arguments is provided
if len(sys.argv) != 29:
    print(len(sys.argv), "input parameters were given instead of 29")
    print("Usage: python main.py <dimension> <back> <control> <photobleaching> <model> <first frame> <postb frame> <last frame> <experiment_name> <where_back> <where_ctrl> <where_roi> <polyctrlx> <polyctrly> <polyfrapx> <polyfrapy> <thickness> <nqc> <timestep> <pixel_size> <tiff_file_path> <output_dir> <kol_test> <all_graphs> <all_graphs> <default_in_par <D_in_par> <beta_in_par> <varepsilon_in_par>")
    sys.exit()
    
# Parse command-line arguments
dimension = int(sys.argv[1])
back = int(sys.argv[2])
control = int(sys.argv[3])
photobleaching = int(sys.argv[4])
model = int(sys.argv[5])
fframe = int(sys.argv[6])-1
pbframe = int(sys.argv[7])-1
lframe = int(sys.argv[8])-1 
experiment_name = sys.argv[9]
where_back = list(map(int,sys.argv[10].split(",")))
where_ctrl = list(map(int,sys.argv[11].split(",")))
where_roi = list(map(int,sys.argv[12].split(",")))
polyctrlx = list(map(float,sys.argv[13].split(",")))  #the coordinates of the polylines does not affect the result of the macro 
polyctrly = list(map(float,sys.argv[14].split(",")))   #but they are saved in the csv file in case re-analysis is neededed
polyfrapx = list(map(float,sys.argv[15].split(",")))
polyfrapy = list(map(float,sys.argv[16].split(",")))
thickness = int(sys.argv[17])
nqc = int(sys.argv[18])
time_step = np.float32(sys.argv[19])
pixel_size = np.float32(sys.argv[20])
tiff_file_path = sys.argv[21]
output_dir = sys.argv[22]
kol_test = int(sys.argv[23])
allGraphs = int(sys.argv[24])
default_ip = int(sys.argv[25])
default_D_ip = np.float32(sys.argv[26])
default_beta_ip = np.float32(sys.argv[27])
default_varepsilon_ip = np.float32(sys.argv[28])

if model == 1:
    model_s = "diffusion"
if model == 2:
    model_s = "reaction-diffusion"
if model == 3:
    model_s = "reaction"
user_initial_guess = [default_D_ip * time_step / pixel_size**2, default_beta_ip * time_step, default_varepsilon_ip ]
    
# Print the parsed values
print(f"Dimension: {dimension}")
print(f"Background: {back}")
print(f"Control: {control}")
print(f"Photobleaching: {photobleaching}")
print(f"Model: {model_s}")
print(f"Nr frames postbleach: {lframe - fframe}")
print(f"Experiment Name: {experiment_name}")
#print(f"Background Coordinates: {where_back}")
#print(f"Control Coordinates: {where_ctrl}")
#print(f"ROI Coordinates: {where_roi}")
print(f"Modes/axis: {nqc}")
print(f"Time Step: {time_step}")
print(f"Pixel size: {pixel_size}")
print(f"Image path: {tiff_file_path}")
print(f"Output Directory: {output_dir}")
print(f"kol_test: {kol_test}")
print(f"all_graphs: {allGraphs}")






def write_results():

    import csv
    # Define the CSV file name
    csv_file = output_dir + "Results.csv"  # File where the inputs and outputs are saved
    # Write the data to the existing CSV file in append mode
    import os
    # Check if the file already exists
    file_exists = os.path.isfile(csv_file)

     #Open the file in append mode if it exists, otherwise create a new file
    with open(csv_file, 'a', newline='') as file:
        writer = csv.writer(file)

        # Write the header only if the file is newly created
        if not file_exists:
            writer.writerow([
                    "Experiment Name",
                    "Dimension",
                    "Model",
                    "Background",
                    "Control",
                    "Photobleaching",
                    "Time step",
                    "Pixel size",
                    "First Frame",
                    "Postbleach frame",
                    "Last frame",
                    "Number of pixels per frames",
                    "Background Coordinates",
                    "Control Coordinates",
                    "ROI Coordinates",
                    "Polyline ctrl [x,y]",
                    "Polyline frap [x,y]",
                    "line thickness",
                    "nqc",
                    "initial_guess [D_in and/or beta_in and/or varepsilon_in]",
                    "D_est",
                    "err_D",
                    "alpha_est",
                    "err_alpha",
                    "beta_est",
                    "err_beta",
                    "varepsilon",
                    "err_varepsilon",
                    "bg_est",
                    "err_bg",
                    "R^2_adj",
                    "kol_pvalue",
                    "varepsilon0",
                    "bg0",
                    "cs",
                    "covM",
                ])

        # Write the data to the file
        writer.writerow([
                experiment_name,
                dimension,
                model_s,
                back,
                control,
                photobleaching,
                time_step,
                pixel_size,
                fframe + 1, #to respect Fiji counting
                pbframe + 1, #to respect Fiji counting
                lframe + 1, #to respect Fiji counting
                nx,
                where_back,
                where_ctrl,
                where_roi,
                polyctrlx + polyctrly,
                polyfrapx + polyfrapy,
                thickness,
                nqc,
                initial_guess,
                D_est,
                err_D,
                alpha_est,
                err_alpha,
                beta_est,
                err_beta,
                varepsilon_est,
                err_varepsilon,
                bg_est,
                err_bg,
                R_2,
                kol_pvalue,
                varepsilon0,
                bg0,
                cs,
                covM
            ])
    print(f"Data appended to '{csv_file}")

    




##########################################################
#1) IMPORT THE TIFF FILE AS A MATRIX
img = imread(tiff_file_path)
if dimension == 1: #import the lines
    if control == 1:
        img_control_1D = imread(output_dir + "line_control.tif")
    img_frap_1D = imread(output_dir + "line_FRAP.tif")

#2)EXTRACT THE REGIONS TO BE ANALYSED

#background
data_bg = img[fframe:lframe+1,where_back[1]:where_back[3],where_back[0]:where_back[2]]                 #check if x,y in fiji are the same axis: FI


#control
if control==0:
    where_ctrl = np.nan
    data_ctrl = np.nan
if control==1:
    if dimension == 1:
        data_ctrl =  img_control_1D[fframe:lframe+1,:,:]
    if dimension ==2:
        data_ctrl =  img[fframe:lframe+1,where_ctrl[1]:where_ctrl[3],where_ctrl[0]:where_ctrl[2]]

#frapped area 
if dimension == 1:
    data_roi = img_frap_1D[fframe:lframe+1,:,:]
if dimension == 2:
    data_roi = img[fframe:lframe+1,where_roi[1]:where_roi[3],where_roi[0]:where_roi[2]]


#extract the dimension of the frapped recovery time-lapse
nt,_,nx=data_roi.shape

#define the number of frames prebleaching
prebleaching = pbframe - fframe

#plot 2D system
# to plot the first postbleaching image
#plt.imshow(data_roi[1,:,:],cmap="gray")
#plt.show()
#sys.exit()

#plot 1D system
# to plot kymograph
#plt.imshow(data_roi[:,0,:],cmap="gray",aspect="auto")
#plt.show()
#sys.exit()




#default values
D_est = np.nan
err_D = np.nan
alpha_est = np.nan
err_alpha = np.nan
beta_est = np.nan
err_beta = np.nan
varepsilon_est = np.nan
err_varepsilon = np.nan
bg_est = np.nan
err_bg = np.nan
R_2 = np.nan
kol_pvalue = np.nan



#PREPROCESSING
#########################
input_pre = data_bg,data_ctrl,data_roi,nqc,back,photobleaching,model,dimension,prebleaching,control,time_step,pixel_size,output_dir,kol_test,allGraphs,experiment_name,default_ip,user_initial_guess
output_pre = preprocessing.compute_preprocessing(input_pre) 
#the ouput is the input for the analysis #output_pre = y,yq,nqc,varepsilon0,dim_y, bg, norm_factor, control,output_dir,kol_test,allGraphs 
#########################


#RUN ANALYSIS AND PRINT THE RESULTS DEPENDING ON THE MODEL
################################


output_analysis = optimisation.runAnalysis(output_pre)

D_est, err_D, beta_est, err_beta , alpha_est, err_alpha, varepsilon_est, err_varepsilon, bg_est, err_bg, R_2, kol_pvalue, varepsilon0, bg0, cs, covM, initial_guess = output_analysis    

if not np.isnan(D_est): print(f"Diffusion coefficient [D_est]: {D_est}")
if not np.isnan(err_D): print(f"Error diffusion [err_D]: {err_D}")
if not np.isnan(beta_est): print(f"Loss rate [beta_est] : {beta_est}")
if not np.isnan(err_beta): print(f"Error loss rate [err_beta] : {err_beta}")
if not np.isnan(alpha_est): print(f"Source rate [alpha_est] : {alpha_est}")
if not np.isnan(err_alpha): print(f"Error source rate [err_alpha] : {err_alpha}")
if not np.isnan(varepsilon_est): print(f"Photobleaching rate [varepsilon_est] : {varepsilon_est}")
if not np.isnan(err_varepsilon): print(f"Error photobleaching [err_varepsilon] : {err_varepsilon}")
if not np.isnan(varepsilon0): print(f"Photobleaching rate from control area [varepsilon0] : {varepsilon0}")
if not np.isnan(bg_est): print(f"Background [bg] : {bg_est}")
if not np.isnan(err_bg): print(f"Error background [err_bg] : {err_bg}")
if not np.isnan(bg0): print(f"Background value from the sample-free area [bg0]: {bg0}")
if not np.isnan(kol_pvalue): print(f"Pvalue for KS test [kol_pvalue]: {kol_pvalue}")
if not np.isnan(R_2): print(f"R squared [R^2_adj]: {R_2}")
  

#WRITE THE RESULTS 
################################
print("Ready")
write_results()








        

"""

The objective of this script is to analyse preprocessed data passed from main.py and perform HiFRAP analysis. 
Depending on the model and the extra-inforomation available (background ROI, control ROI or prebleaching images) the objective function is chosen. All the functions are defined in functions.py
Once the cost is minimized all the inferred paramters are extracted.
At the end, output results are plotted in plot_results.py and pass back to main.py

"""


#IMPORT PACKAGES
###############################################################################################################################
###############################################################################################################################
import numpy as np
from scipy.special import erf
import random as rd
import scipy
from scipy import special
from scipy import optimize
import matplotlib.pyplot as plt
import time
from scipy.optimize import NonlinearConstraint,curve_fit
from csv import writer
import numpy as np
import random as rd
import scipy
from scipy import special
from scipy import optimize
import time
from scipy.optimize import NonlinearConstraint
from scipy.linalg import solve
from csv import writer
from scipy.fft import fft,ifft,fft2,ifft2
import pandas as pd
from scipy.stats import kstest
from opt_einsum import contract
import functions as f
import plot_results
import preprocessing 
import matplotlib.gridspec as gridspec
import sys 



def runAnalysis(input):
    #extract all the parameters
    y,yq,varepsilon0,bg0,cs,dim_y,norm_factor,output_dir,kol_test,allGraphs,experiment_name,default_ip,user_initial_guess = input  #probabily here you need to define cs and I 
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y
    model_s = "diff" if model == 1 else "reac-diff" if model == 2 else "reac" if model == 3 else None

    #define boundaries for the numeric minimisation relative to the initial guess
    bound_D = [(nx/nqc)**2/nt/40,nx**2/5]
    bound_beta = [-3/nt, 100*1/nt]
    bound_varepsilon = [1/nt/10, 100*1/nt]

    """
    For each model, control and probleaching I prescribe the function to minimize and how to extract the parameters 
    from the minimisation
    """

    if model==1:
        if control==1:
            if back==1 or photobleaching==0:
            ##########################################################################################################################################################################################
                print("Diffusion-only optimisation")#1
                n_theta = 1 
                initial_guess = f.compute_initial_guess(y, dim_y, True, False, False) if default_ip == 1 else user_initial_guess[0]
                bounds = bound_D
                def objective(param):
                    D = param                           
                    return f.residuals_reduced_K_full_lapack(D,0,varepsilon0,bg0,cs,yq,dim_y)
                def extract_parameters(res_opt):
                    D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                    D_est = np.squeeze(res_opt.x)
                    residual,Cmin,TrF,bg,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,0,varepsilon0,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                    J = np.array(res_opt.jac)
                    err_D,covM = f.compute_error(J,Cmin,TrF)
                    R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                    if kol_test==1: kol_pvalue = f.kolmogorov_test( D_est,0,alpha_est,varepsilon0,bg0,cs,yq,dim_y)
                    return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                ##########################################################################################################################################################################################
            else:
                ##########################################################################################################################################################################################
                print("Diffusion-background optimisation")#2
                n_theta = 2 
                initial_guess = f.compute_initial_guess(y, dim_y, True, False, False) if default_ip == 1 else user_initial_guess[0]
                bounds = bound_D
                def objective(param):
                    D = param                           
                    return f.residuals_reduced_K_full_lapack(D,0,varepsilon0,bg0,cs,yq,dim_y)
                def extract_parameters(res_opt):
                    D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                    D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                    D_est = np.squeeze(res_opt.x)
                    residual,Cmin,TrF,bg,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,0,varepsilon0,bg,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                    J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(param,0,varepsilon0,bg0,cs,yq,dim_y,implicit=False,bg=bg_est), 1e-2*res_opt.x)
                    J = np.hstack([J,J_bg.reshape(-1,1)])
                    err_D, err_bg, covM = f.compute_error(J,Cmin,TrF)
                    R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                    if kol_test==1: kol_pvalue = f.kolmogorov_test( D_est,0,alpha_est,varepsilon0,bg_est,cs,yq,dim_y)
                    return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                ##########################################################################################################################################################################################
        if control == 0:
            if back==1 or photobleaching==0:
                ##########################################################################################################################################################################################
                print("Diffusion-photobleaching optimisation") #3
                n_theta = 2 
                initial_guess = f.compute_initial_guess(y, dim_y, True, False, True) if default_ip == 1 else [user_initial_guess[0],user_initial_guess[2]]
                bounds = [[d , ve ] for d, ve in zip(bound_D, bound_varepsilon)]
                def objective(param):
                    D,varepsilon = param 
                    return f.residuals_reduced_K_full_lapack(D,0,varepsilon,bg0,cs,yq,dim_y)
                def extract_parameters(res_opt):
                    D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                    D_est,varepsilon_est = res_opt.x
                    residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,0,varepsilon_est,bg0,cs,yq,dim_y,return_all=True)
                    J = np.array(res_opt.jac)
                    err_D,err_varepsilon,covM = f.compute_error(J,Cmin,TrF)
                    R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                    if kol_test==1: kol_pvalue = f.kolmogorov_test( D_est,0,alpha_est,varepsilon_est,bg0,cs, yq,dim_y)
                    return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                ##########################################################################################################################################################################################
            else:   
                ##########################################################################################################################################################################################
                print("Diffusion-photobleaching-background optimisation")#4
                n_theta = 3 
                initial_guess = f.compute_initial_guess(y, dim_y, True, False, True) if default_ip == 1 else [user_initial_guess[0],user_initial_guess[2]]
                bounds = [[d , ve ] for d, ve in zip(bound_D, bound_varepsilon)]
                def objective(param):
                    D,varepsilon = param
                    return f.residuals_reduced_K_full_lapack(D,0,varepsilon,bg0,cs,yq,dim_y)
                def extract_parameters(res_opt):
                    D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                    D_est,varepsilon_est = res_opt.x
                    residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,0,varepsilon_est,bg0,cs,yq,dim_y,return_all=True)
                    J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(param[0],0,param[1],bg0,cs,yq,dim_y,implicit=False,bg=bg_est), 1e-2*res_opt.x)
                    J = np.hstack([J,J_bg.reshape(-1,1)])
                    err_D, err_varepsilon, err_bg,covM = f.compute_error(J,Cmin,TrF)
                    R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                    if kol_test==1: kol_pvalue = f.kolmogorov_test( D_est,0,alpha_est,varepsilon_est,bg_est,cs, yq,dim_y)
                    return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                ##########################################################################################################################################################################################



    if model == 2:
        if control == 1:
            if prebleaching > 0:
                if back==1 or photobleaching==0:
                    ##########################################################################################################################################################################################
                    print("Diffusion-loss optimisation")#5
                    n_theta = 2 
                    initial_guess = f.compute_initial_guess(y, dim_y, True, True, False) if default_ip == 1 else [user_initial_guess[0],user_initial_guess[1]]
                    bounds = [[d , b ] for d, b in zip(bound_D, bound_beta)]
                    def objective(param):
                        D,beta = param                           
                        return f.residuals_reduced_K_full_lapack(D,beta,varepsilon0,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        D_est,beta_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,beta_est,varepsilon0,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = np.array(res_opt.jac)
                        err_D,err_beta,covM = f.compute_error(J,Cmin,TrF)
                        alpha_est = cs * beta_est
                        err_alpha = cs * err_beta
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( D_est,beta_est,alpha_est,varepsilon0,bg0,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
                else:
                    ##########################################################################################################################################################################################
                    print("Diffusion-loss-background optimisation")#6
                    n_theta = 3 
                    initial_guess = f.compute_initial_guess(y, dim_y, True, True, False) if default_ip == 1 else [user_initial_guess[0],user_initial_guess[1]]
                    bounds = [[d , b ] for d, b in zip(bound_D, bound_beta)]
                    def objective(param):
                        D,beta = param                           
                        return f.residuals_reduced_K_full_lapack(D,beta,varepsilon0,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        D_est, alpha_est, beta_est, varepsilon_est, err_D, err_alpha, err_beta, err_varepsilon, bg_est,err_bg,residual,Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        D_est,beta_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,beta_est,varepsilon0,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(param[0],param[1],varepsilon0,bg0,cs,yq,dim_y,implicit=False,bg=bg_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_bg.reshape(-1,1)])
                        err_D,err_beta, err_bg,covM = f.compute_error(J,Cmin,TrF)
                        alpha_est = (cs - bg_est) * beta_est 
                        err_alpha = np.sqrt(beta_est**2 * err_bg**2 + (cs - bg_est)**2*err_beta**2) #linear  propagation error
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test(D_est,beta_est,alpha_est,varepsilon0,bg_est,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
            if prebleaching < 1:
                if back==1 or photobleaching==0:
                    ##########################################################################################################################################################################################
                    print("Diffusion-loss-source optimisation")#7
                    n_theta = 3 
                    initial_guess = f.compute_initial_guess(y, dim_y, True, True, False) if default_ip == 1 else [user_initial_guess[0],user_initial_guess[1]]
                    bounds = [[d , b ] for d, b in zip(bound_D, bound_beta)]
                    def objective(param):
                        D,beta = param                           
                        return f.residuals_reduced_K_full_lapack(D,beta,varepsilon0,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        D_est,beta_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,beta_est,varepsilon0,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(param[0],param[1],varepsilon0,bg0,cs,yq,dim_y,implicit=False,alpha=alpha_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_alp.reshape(-1,1)])
                        err_D,err_beta,err_alpha,covM = f.compute_error(J,Cmin,TrF)
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( D_est,beta_est,alpha_est,varepsilon0,bg0,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
                else:
                    ##########################################################################################################################################################################################
                    print("Diffusion-loss-source-background optimisation")#8
                    n_theta =  4
                    initial_guess = f.compute_initial_guess(y, dim_y, True, True, False) if default_ip == 1 else [user_initial_guess[0],user_initial_guess[1]]
                    bounds = [[d , b ] for d, b in zip(bound_D, bound_beta)]
                    def objective(param):
                        D,beta = param                           
                        return f.residuals_reduced_K_full_lapack(D,beta,varepsilon0,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        D_est,beta_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,beta_est,varepsilon0,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(param[0],param[1],varepsilon0,bg0,cs,yq,dim_y,implicit=False,bg=bg_est,alpha=alpha_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_bg.reshape(-1,1)]); J = np.hstack([J,J_alpha.reshape(-1,1)])
                        err_D,err_beta,err_bg,err_alpha,covM = f.compute_error(J,Cmin,TrF)
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( D_est,beta_est,alpha_est,varepsilon0,bg_est,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
        if control == 0:
            if prebleaching > 0:
                if back==1 or photobleaching==0:
                    ##########################################################################################################################################################################################
                    print("Diffusion-loss-photobleaching optimisation")#9
                    n_theta = 3 
                    initial_guess = f.compute_initial_guess(y, dim_y, True, True, True) if default_ip == 1 else [user_initial_guess[0],user_initial_guess[1],user_initial_guess[2]]
                    bounds = [[d , b , ve ] for d, b, ve in zip(bound_D, bound_beta, bound_varepsilon)]
                    def objective(param):
                        D,beta,varepsilon = param                           
                        return f.residuals_reduced_K_full_lapack(D,beta,varepsilon,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        D_est,beta_est,varepsilon_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,beta_est,varepsilon_est,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = np.array(res_opt.jac)
                        err_D,err_beta,err_varepsilon,covM = f.compute_error(J,Cmin,TrF)
                        alpha_est = cs * beta_est
                        err_alpha = cs * err_beta
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( D_est,beta_est,alpha_est,varepsilon_est,bg0,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
                else:
                    ##########################################################################################################################################################################################
                    print("Diffusion-loss-photobleaching-background optimisation") #10
                    n_theta = 4
                    initial_guess = f.compute_initial_guess(y, dim_y, True, True, True) if default_ip == 1 else [user_initial_guess[0],user_initial_guess[1],user_initial_guess[2]]
                    bounds = [[d , b , ve ] for d, b, ve in zip(bound_D, bound_beta, bound_varepsilon)]
                    def objective(param):
                        D,beta,varepsilon = param                           
                        return f.residuals_reduced_K_full_lapack(D,beta,varepsilon,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        D_est,beta_est,varepsilon_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,beta_est,varepsilon_est,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(param[0],param[1],param[2],bg0,cs,yq,dim_y,implicit=False,bg=bg_est,alpha=alpha_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_bg.reshape(-1,1)]);
                        err_D,err_beta,err_varepsilon,err_bg,covM = f.compute_error(J,Cmin,TrF)
                        alpha_est = (cs - bg_est) * beta_est 
                        err_alpha = np.sqrt(beta_est**2 * err_bg**2 + (cs - bg_est)**2*err_beta**2) #linear  propagation error
                        yq0 = yq.copy(); yq0[:,0,0] -= np.mean(yq[:,0,0]); R_2 = 1 - (Cmin * TrF / (TrF - n_theta)) / np.sum(yq0**2/yq0.size-1)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( D_est,beta_est,alpha_est,varepsilon_est,bg_est,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
            if prebleaching < 1:
                if back==1 or photobleaching==0:
                    ##########################################################################################################################################################################################
                    print("Diffusion-loss-source-photobleaching optimisation")#11
                    n_theta = 4 
                    initial_guess = f.compute_initial_guess(y, dim_y, True, True, True) if default_ip == 1 else [user_initial_guess[0],user_initial_guess[1],user_initial_guess[2]]
                    bounds = [[d , b , ve ] for d, b, ve in zip(bound_D, bound_beta, bound_varepsilon)]
                    def objective(param):
                        D,beta,varepsilon = param                           
                        return f.residuals_reduced_K_full_lapack(D,beta,varepsilon,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        D_est,beta_est,varepsilon_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,beta_est,varepsilon_est,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(param[0],param[1],param[2],varepsilon0,bg0,cs,yq,dim_y,implicit=False,alpha=alpha_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_alpha.reshape(-1,1)])
                        err_D,err_beta,err_varepsilon,err_alpha,covM = f.compute_error(J,Cmin,TrF)
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( D_est,beta_est,alpha_est,varepsilon_est,bg0,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
                else:
                    ##########################################################################################################################################################################################
                    print("Diffusion-loss-source-photobleaching-background optimisation") #12
                    n_theta = 5
                    initial_guess = f.compute_initial_guess(y, dim_y, True, True, True) if default_ip == 1 else [user_initial_guess[0],user_initial_guess[1],user_initial_guess[2]]
                    bounds = [[d , b , ve ] for d, b, ve in zip(bound_D, bound_beta, bound_varepsilon)]
                    def objective(param):
                        D,beta,varepsilon = param                           
                        return f.residuals_reduced_K_full_lapack(D,beta,varepsilon,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        D_est,beta_est,varepsilon_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(D_est,beta_est,varepsilon_est,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(param[0],param[1],param[2],bg0,cs,yq,dim_y,implicit=False,bg=bg_est,alpha=alpha_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_bg.reshape(-1,1)]) ; J = np.hstack([J,J_alpha.reshape(-1,1)])
                        err_D,err_beta,err_varepsilon,err_bg,err_alpha,covM = f.compute_error(J,Cmin,TrF)
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test(D_est,beta_est,alpha_est,varepsilon_est,bg_est,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
    if model == 3:
        if control == 1:
            if prebleaching > 0:
                if back==1 or photobleaching==0:
                    ##########################################################################################################################################################################################
                    print("Loss-rate optimisation")#13
                    n_theta = 2 
                    initial_guess = f.compute_initial_guess(y,dim_y,False,True,False)
                    bounds = bound_beta
                    def objective(param):
                        beta = param                           
                        return f.residuals_reduced_K_full_lapack(0,beta,varepsilon0,bg0,cs,yq,dim_y) #D=0 
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        beta_est = np.squeeze(res_opt.x)
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(0,beta_est,varepsilon0,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = np.array(res_opt.jac)
                        err_beta,covM = f.compute_error(J,Cmin,TrF)
                        alpha_est = cs * beta_est
                        err_alpha = cs * err_beta
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( 0,beta_est,alpha_est,varepsilon0,bg0,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
                else:
                    ##########################################################################################################################################################################################
                    print("Loss-rate-background optimisation")#14 
                    n_theta = 3
                    initial_guess = f.compute_initial_guess(y,dim_y,False,True,False)
                    bounds = bound_beta
                    def objective(param):
                        beta = param                           
                        return f.residuals_reduced_K_full_lapack(0,beta,varepsilon0,bg0,cs,yq,dim_y) #D=0 
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        beta_est = np.squeeze(res_opt.x)
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(0,beta_est,varepsilon0,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(0,param,varepsilon0,bg0,cs,yq,dim_y,implicit=False,bg=bg_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_bg.reshape(-1,1)])
                        err_beta,err_bg,covM = f.compute_error(J,Cmin,TrF)
                        alpha_est = (cs - bg_est) * beta_est 
                        err_alpha = np.sqrt(beta_est**2 * err_bg**2 + (cs - bg_est)**2*err_beta**2) #linear  propagation error
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( 0,beta_est,alpha_est,varepsilon0,bg_est,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################

            if prebleaching < 1:
                if back==1 or photobleaching==0 :
                    ##########################################################################################################################################################################################
                    print("Source-loss-rate optimisation")#15 
                    n_theta = 3
                    initial_guess = f.compute_initial_guess(y, dim_y, False, True, False) if default_ip == 1 else user_initial_guess[1]
                    bounds = bound_beta
                    def objective(param):
                        beta = param                           
                        return f.residuals_reduced_K_full_lapack(0,beta,varepsilon0,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        beta_est = np.squeeze(res_opt.x)
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(0,beta_est,varepsilon0,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(0,param,varepsilon0,bg0,cs,yq,dim_y,implicit=False,bg=bg_est,alpha=alpha_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_alpha.reshape(-1,1)])
                        err_beta,err_alpha,covM = f.compute_error(J,Cmin,TrF)
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( 0,beta_est,alpha_est,varepsilon0,bg0,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
                else :
                    ##########################################################################################################################################################################################
                    print("Source-loss-rate-background optimisation")#16
                    n_theta = 3
                    initial_guess = f.compute_initial_guess(y, dim_y, False, True, False) if default_ip == 1 else user_initial_guess[1]
                    bounds = bound_beta
                    def objective(param):
                        beta = param                           
                        return f.residuals_reduced_K_full_lapack(0,beta,varepsilon0,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        beta_est = np.squeeze(res_opt.x)
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(0,beta_est,varepsilon0,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(0,param,varepsilon0,bg0,cs,yq,dim_y,implicit=False,bg=bg_est,alpha=alpha_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_bg.reshape(-1,1)]); J = np.hstack([J,J_alpha.reshape(-1,1)]) 
                        err_beta,err_bg, err_alpha,covM = f.compute_error(J,Cmin,TrF)
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( 0,beta_est,alpha_est,varepsilon0,bg_est,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                        ##########################################################################################################################################################################################
        if control == 0:
            if prebleaching > 0:
                if back==1 or photobleaching==0 :
                    ##########################################################################################################################################################################################
                    print("Loss-photobleaching optimisation")#17
                    n_theta = 2
                    initial_guess = f.compute_initial_guess(y, dim_y, False, True, True) if default_ip == 1 else [user_initial_guess[1],user_initial_guess[2]]
                    bounds = [[b , ve ] for b, ve in zip(bound_beta, bound_varepsilon)]
                    def objective(param):
                        beta,varepsilon = param                           
                        return f.residuals_reduced_K_full_lapack(0,beta,varepsilon,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        beta_est,varepsilon_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(0,beta_est,varepsilon_est,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = np.array(res_opt.jac)
                        err_beta,err_varepsilon,covM = f.compute_error(J,Cmin,TrF)
                        alpha_est = cs * beta_est
                        err_alpha = cs * err_beta
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( 0,beta_est,alpha_est,varepsilon_est,bg0,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################                 
                else:
                    ##########################################################################################################################################################################################
                    print("Loss-photobleaching-background optimisation")#18
                    n_theta = 3 
                    initial_guess = f.compute_initial_guess(y, dim_y, False, True, True) if default_ip == 1 else [user_initial_guess[1],user_initial_guess[2]]
                    bounds = [[b , ve ] for b, ve in zip(bound_beta, bound_varepsilon)]
                    def objective(param):
                        beta,varepsilon = param                           
                        return f.residuals_reduced_K_full_lapack(0,beta,varepsilon,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        beta_est,varepsilon_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(0,beta_est,varepsilon_est,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(0,param[0],param[1],bg0,cs,yq,dim_y,implicit=False,bg=bg_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_bg.reshape(-1,1)]);
                        err_beta,err_varepsilon,err_bg,covM = f.compute_error(J,Cmin,TrF)
                        alpha_est = (cs - bg_est) * beta_est 
                        err_alpha = np.sqrt(beta_est**2 * err_bg**2 + (cs - bg_est)**2*err_beta**2) #linear  propagation error
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( 0,beta_est,alpha_est,varepsilon_est,bg_est,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                        ##########################################################################################################################################################################################
            if prebleaching < 1:
                if back==1 or photobleaching==0 :
                    ##########################################################################################################################################################################################
                    print("Source-loss-photobleaching optimisation") #19
                    n_theta = 3
                    initial_guess = f.compute_initial_guess(y, dim_y, False, True, True) if default_ip == 1 else [user_initial_guess[1],user_initial_guess[2]]
                    bounds = [[b , ve ] for b, ve in zip(bound_beta, bound_varepsilon)]
                    def objective(param):
                        beta,varepsilon = param                           
                        return f.residuals_reduced_K_full_lapack(0,beta,varepsilon,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        beta_est,varepsilon_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(0,beta_est,varepsilon_est,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = np.hstack([np.array(res_opt.jac),J_alpha.reshape(-1,1)])
                        err_beta,err_varepsilon,err_alpha,covM = f.compute_error(J,Cmin,TrF)
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( 0,beta_est,alpha_est,varepsilon_est,bg0,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                    ##########################################################################################################################################################################################
                else:
                    ##########################################################################################################################################################################################
                    print("Source-loss-photobleaching-background optimisation")  #20
                    n_theta = 4
                    initial_guess = f.compute_initial_guess(y, dim_y, False, True, True) if default_ip == 1 else [user_initial_guess[1],user_initial_guess[2]]
                    bounds = [[b , ve ] for b, ve in zip(bound_beta, bound_varepsilon)]
                    def objective(param):
                        beta,varepsilon = param                           
                        return f.residuals_reduced_K_full_lapack(0,beta,varepsilon,bg0,cs,yq,dim_y)
                    def extract_parameters(res_opt):
                        D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = [np.nan]*16 
                        beta_est,varepsilon_est = res_opt.x
                        residual,Cmin,TrF,bg_est,alpha_est,J_bg,J_alpha = f.residuals_reduced_K_full_lapack(0,beta_est,varepsilon_est,bg0,cs,yq,dim_y,return_all=True)  #computation of the residuals and the trace (effective paramters) at the min
                        J = scipy.optimize.approx_fprime(res_opt.x, lambda param: f.residuals_reduced_K_full_lapack(0,param[0],param[1],bg0,cs,yq,dim_y,implicit=False,bg=bg_est,alpha=alpha_est), 1e-2*res_opt.x)
                        J = np.hstack([J,J_bg.reshape(-1,1)]); J = np.hstack([J,J_alpha.reshape(-1,1)])
                        err_beta,err_varepsilon,err_bg, err_alpha,covM = f.compute_error(J,Cmin,TrF)
                        R_2 = f.compute_R_squared_adj(Cmin,yq,TrF,dim_y,n_theta)
                        if kol_test==1: kol_pvalue = f.kolmogorov_test( 0,beta_est,alpha_est,varepsilon_est,bg_est,cs,yq,dim_y)
                        return D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM
                        ##########################################################################################################################################################################################

    # Check if each initial_guess[i] is inside bounds[i]
    x0 = np.atleast_1d(initial_guess)
    lb = np.atleast_1d(bounds[0])
    ub = np.atleast_1d(bounds[1])
    if np.all((x0 >= lb) & (x0 <= ub))==False:
        print(f"Error: The initial guess is outside the bounds given by the spatial-temporal resolution (D = [{bound_D[0]*pixel_size**2/time_step}, {bound_D[1]*pixel_size**2/time_step}] um^2/s, beta = [{bound_beta[0]/time_step}, {bound_beta[1]/time_step}] 1/s and varepsilon = [{bound_varepsilon[0]}, {bound_varepsilon[1]}]).")
        sys.exit(1)  # Exit the program immediately

    #perform optimisation    
    res_opt = scipy.optimize.least_squares(objective,x0 = initial_guess,bounds=bounds, x_scale = np.abs(initial_guess), #Scale of the parameters    
            method='trf',           # Algorithm: 'trf', 'dogbox', 'lm' (default: 'trf')   
            xtol=1e-4,              #Tolerance for the parameter
            ftol=1e-12,             # Tolerance for cost function
            gtol=1e-12,             # Tolerance for gradient norm
            loss='linear',          # Loss function: 'linear', 'soft_l1', 'huber', etc.
            diff_step=1e-2,         # Step size for numerical derivatives (None uses default)
            tr_solver=None,         # Trust-region solver ('exact', 'lsmr', or None)
            tr_options={},          # Options for trust-region solver
            jac='2-point',          # Jacobian: '2-point', '3-point', callable, or None
            max_nfev=500,           # Maximum number of function evaluations
            verbose=0 )  
    
    D_est, alpha_est, beta_est, varepsilon_est, bg_est, err_D, err_alpha, err_beta, err_varepsilon, err_bg, residual, Cmin, TrF, R_2, kol_pvalue, covM = extract_parameters(res_opt)

    


    if np.isnan(varepsilon_est):
        varepsilon = varepsilon0
    else:
        varepsilon = varepsilon_est

    
    #plot all the graps (data + compression + fit + residuals + cost function )
    if allGraphs == 1:
        plt.figure(1)
        plot_results.plot_data_vs_fit(y,bg0, cs, yq, dim_y,residual,TrF,norm_factor)
        plt.savefig(output_dir+experiment_name+"_"+model_s+"_"+"Data_Fit.pdf",dpi=300)
        

        if not np.isnan(err_D):   
            plt.figure(2)
            plot_results.plot_cost_D(D_est, err_D,beta_est,varepsilon, bg0 , cs, yq, dim_y, Cmin,norm_factor, logspace=True)
            plt.savefig(output_dir+experiment_name+"_"+model_s+"_"+"cost_D_log.pdf",dpi=300)
            plt.figure(3)
            plot_results.plot_cost_D(D_est, err_D,beta_est,varepsilon, bg0 , cs, yq, dim_y, Cmin,norm_factor, logspace=False)
            plt.savefig(output_dir+experiment_name+"_"+model_s+"_"+"cost_D.pdf",dpi=300)

        
        if not np.isnan(err_beta):
            plt.figure(4)
            plot_results.plot_cost_beta(D_est, beta_est, err_beta, varepsilon, bg0 , cs, yq, dim_y, Cmin,norm_factor, logspace=True)
            plt.savefig(output_dir+experiment_name+"_"+model_s+"_"+"cost_log_beta.pdf",dpi=300)
            plt.figure(5)
            plot_results.plot_cost_beta(D_est,beta_est,err_beta, varepsilon, bg0 , cs, yq, dim_y, Cmin,norm_factor, logspace=False)
            plt.savefig(output_dir+experiment_name+"_"+model_s+"_"+"cost_log_beta.pdf",dpi=300)

        if not np.isnan(err_varepsilon):
            plt.figure(6)
            plot_results.plot_cost_varepsilon(D_est, beta_est, varepsilon, err_varepsilon, bg0 , cs, yq, dim_y, Cmin,norm_factor, logspace=True)
            plot_results.plt.savefig(output_dir+experiment_name+"_"+model_s+"_"+"cost_varepsilon_log.pdf",dpi=300)
            plt.figure(7)
            plot_results.plot_cost_varepsilon(D_est,beta_est, varepsilon, err_varepsilon, bg0 , cs, yq, dim_y, Cmin,norm_factor, logspace=False)
            plt.savefig(output_dir+experiment_name+"_"+model_s+"_"+"cost_varepsilon.pdf",dpi=300)
    
        plt.show()



    #aranaging the result in 1 list and transform it in the right unit    
    D_est = D_est*pixel_size**2/time_step
    err_D = err_D*pixel_size**2/time_step
    beta_est = beta_est / time_step
    err_beta = err_beta/time_step
    alpha_est = alpha_est * norm_factor[1]
    err_alpha = err_alpha * norm_factor[1]
    cs = cs * norm_factor[1]
    bg_est = (bg_est * norm_factor [1]) + norm_factor[0]
    err_bg = (err_bg * norm_factor [1]) 
    bg0 = (bg0 * norm_factor[1]) + norm_factor[0]
    p = 0
    if not np.isnan(D_est):
        initial_guess[p] *= pixel_size**2 / time_step
        p += 1
    if not np.isnan(beta_est): initial_guess[p] /= time_step

     
    ouput = D_est, err_D, beta_est, err_beta , alpha_est, err_alpha, varepsilon_est, err_varepsilon, bg_est, err_bg, R_2, kol_pvalue, varepsilon0, bg0, cs, covM, initial_guess
    
    return ouput




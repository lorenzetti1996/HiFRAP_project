"""

In this script, the results are plotted.

"""
#IMPORT PACKAGES
###############################################################################################################################
###############################################################################################################################
import numpy as np
from scipy.special import erf
import random as rd
import scipy
from scipy import special
from scipy import optimize
import matplotlib.pyplot as plt
import time
from scipy.optimize import NonlinearConstraint,curve_fit
from csv import writer
import numpy as np
import random as rd
import scipy
from scipy import special
from scipy import optimize
import time
from scipy.optimize import NonlinearConstraint
from scipy.linalg import solve
from csv import writer
from scipy.fft import fft,ifft,fft2,ifft2
import pandas as pd
from scipy.stats import kstest
from opt_einsum import contract
import functions as f
import matplotlib.gridspec as gridspec
import functions as f
import preprocessing 
import optimisation



def plot_data_vs_fit(y, bg, cs, yq, dim_y,residuals,TrF,norm_factor): # 
    """
    
    Plot signal data vector vs compressed vector vs curve fit vs residuals in the real space
    In 1D: Kymograph (signal intensity time vs space)
    In 2D: 4 Frames at t=0 t=T/3 and t=2/3T and t=T
    
    """
    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size  = dim_y
    
    yqfit = yq - residuals * np.sqrt(TrF) #the residuals were normalised by the trace
    ycom = f.from_fourier_to_realspace(yq,dim_y)
    yf = f.from_fourier_to_realspace(yqfit,dim_y)

    y=(y * norm_factor [1]) + norm_factor[0]
    ycom=(ycom * norm_factor [1]) + norm_factor[0]
    yf=(yf * norm_factor [1]) + norm_factor[0]

    if dimension == 1:
        residuals_real = yf - ycom
        Y_to_fit = [y, ycom, yf, residuals_real]
            
        fig = plt.gcf() 
        gs = gridspec.GridSpec(2, 4, height_ratios=[20, 1], hspace=0.3, wspace=0.2)

        column_titles = ["Data", "Comp", "Fit", "Res"]
        t = np.arange(0, nt) * time_step
        x = np.arange(0, nx) * pixel_size
        X, T = np.meshgrid(x, t)

        im_handles = []

        for i in range(4):
            ax = fig.add_subplot(gs[0, i])
            if i!=3:
                im = ax.imshow(Y_to_fit[i], cmap="gray", aspect='auto', vmin=np.min(y)*1.1,  vmax=np.max(y)*0.9)
            else:
                im = ax.imshow(Y_to_fit[i], cmap="gray", aspect='auto', vmin=-np.max(np.abs(Y_to_fit[i])),  vmax=np.max(np.abs(Y_to_fit[i])))
            im_handles.append(im)
            ax.set_title(column_titles[i], fontsize=12)
            ax.set_xlabel(r"$\text{Position} \, [px]$")
            if i == 0:
                ax.set_ylabel(r"$\text{Time} \, [\Delta t]$")
            else:
                ax.set_yticks([])

        
        
        
        
        # Now the colorbars below the x-labels
        cbar_ax1 = fig.add_subplot(gs[1, 0:3])
        cbar1 = fig.colorbar(im_handles[0], cax=cbar_ax1, orientation='horizontal')
        cbar1.set_label('Data/Comp/Fit Intensity [A.U.]')

        cbar_ax2 = fig.add_subplot(gs[1, 3])
        cbar2 = fig.colorbar(im_handles[3], cax=cbar_ax2, orientation='horizontal')
        cbar2.set_label('Residuals Intensity [A.U.]')


    if dimension == 2 :
        

        index=[0,nt//3,2*nt//3,nt-1]
        gs = gridspec.GridSpec(4, 5, width_ratios=[10,10,10,10,1], hspace=0.1, wspace=0.1)
        plt.subplots_adjust(left = 0.15,right=0.8,top = 0.9, bottom=0.1,wspace=0.01, hspace=0.01)


        # Create main plot axes
        axs=[]
        for i in range(0,4):
            for j in range(0,4):
                ax=plt.subplot(gs[i,j])
                axs.append(ax)
        cbar_ax1 = plt.subplot(gs[0:3, -1])
        cbar_ax2 = plt.subplot(gs[-1, -1])


        vmin=np.min(y)*1.1
        vmax=np.max(y)*0.9


        # Titles for rows
        row_titles = ["Data", "Comp", "Fit", "Res"]
        column_titles = [rf"$t = {idx} \Delta t$" for idx in index]
      

        for i, title in enumerate(row_titles):
            fig =  plt.subplot(gs[i,0])
            fig.set_ylabel(title,fontsize=14)
        for j, title in enumerate(column_titles):
            fig =  plt.subplot(gs[0,j])
            fig.set_title(title,fontsize=14)


        for i in range(4):
            ax=plt.subplot(gs[0,i])
            im = ax.imshow(y[index[i], :, :], origin='lower', vmin=vmin, vmax=vmax,cmap="gray")
            ax.set_xticks([]); ax.set_yticks([])
        
        for i in range(4):
            ax=plt.subplot(gs[1,i])
            im = ax.imshow(ycom[index[i], :, :], origin='lower', vmin=vmin, vmax=vmax,cmap="gray")
            ax.set_xticks([]); ax.set_yticks([])

        for i in range(4):
            ax=plt.subplot(gs[2,i])
            im = ax.imshow(yf[index[i], :, :], origin='lower',  vmin=vmin, vmax=vmax,cmap="gray")
            ax.set_xticks([]); ax.set_yticks([])


        for i in range(4):
            res=ycom[index[i], :, :]-yf[index[i], :, :]
            vlim = np.max(np.abs(res))
            ax=plt.subplot(gs[3,i])
            im2 = ax.imshow(res, origin='lower',cmap="coolwarm",vmin=-0.9*vlim,vmax=0.9*vlim)
            ax.set_xticks([]); ax.set_yticks([])

            
        plt.colorbar(im, cax=cbar_ax1)
        plt.colorbar(im2, cax=cbar_ax2)





def plot_cost_D(D_est, err_D, beta_est,varepsilon_est, bg, cs, yq, dim_y, Cmin, norm_factor, logspace=False):
    
    """
    
    Plot the cost function for the diffusion constant in log scale or linear scale around the minimum
    
    """


    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    if np.isnan(beta_est): beta_est = 0 #When the model does not include reaction
    if np.isnan(varepsilon_est): varepsilon_est = 0

    n_points = 11 #number of sampling points of the cost function
    if  logspace==True:
        Din = np.logspace(-2,2,n_points)*D_est
    else: 
        Din = np.linspace(D_est-3*err_D,D_est+3*err_D,n_points)

    C = [np.sum(f.residuals_reduced_K_full_lapack(D,beta_est, varepsilon_est, bg, cs, yq, dim_y)**2) for D in Din] #remember to account for the factor norm_factor
    

    if  logspace==True:
        plt.plot(Din / D_est, np.array(C)/Cmin,linewidth=3)
        plt.xscale('log')
        plt.xlabel(r"Diffusion $[D/ D_{est}]$")
        plt.ylabel(r"Cost $[C/C_{min}]$")
        plt.title('Cost Function (log)')
    else: 
        plt.plot(Din*pixel_size**2/time_step, np.array(C)*norm_factor[1]**2,linewidth=3)
        #plt.xticks([0.97,0.98,0.99,1,1.01,1.02])
        plt.xlabel(r"Diffusion [$\mu m^2/s$]")
        plt.ylabel(r"Cost $[A.U.]$")
        plt.title('Cost Function ')

    plt.grid()


def plot_cost_beta(D_est,beta_est,err_beta, varepsilon_est, bg, cs, yq, dim_y, Cmin, norm_factor, logspace=False):
    """
    
    Plot the cost function for exchange-rate in log scale or linear scale around the minimum
    
    """

    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    if np.isnan(D_est): D_est = 0 #When the model does not include diffusion
    if np.isnan(varepsilon_est): varepsilon_est = 0


    if  logspace==True:
        betain = np.logspace(-2,2,11)*beta_est
    else: 
        betain = np.linspace(beta_est-3*err_beta,beta_est+3*err_beta,11)

    C = [np.sum(f.residuals_reduced_K_full_lapack(D_est,beta, varepsilon_est, bg, cs, yq, dim_y)**2) for beta in betain] 
    

    if  logspace==True:
        plt.plot(betain / beta_est, np.array(C)/Cmin,linewidth=3)
        plt.xscale('log')
        #plt.xlabel(r"Loss rate [$\beta / \beta_{\text{est}}$]")
        #plt.ylabel(r"Cost $[C/C_{min}]$")
        plt.title('Cost Function loss rate (log)')
    else: 
        plt.plot(betain/time_step, np.array(C)*norm_factor[1]**2,linewidth=3)
        plt.xlabel(r"Cost Function loss rate/frame $[1/s]$")
        plt.ylabel(r"Cost $[A.U.]$")
        plt.title('Cost Function ')

    plt.grid()

def plot_cost_varepsilon(D_est,beta_est,varepsilon_est,err_varepsilon,bg,cs,yq, dim_y, Cmin, norm_factor, logspace=False):
    
    """
    
    Plot the cost function for the photobleaching decay-rate in log scale or linear scale around the minimum
    
    """


    model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size = dim_y 

    if np.isnan(D_est): D_est = 0 #When the model does not include diffusion
    if np.isnan(beta_est): beta_est = 0


    if  logspace==True:
        var_in = np.logspace(-2,2,11)*varepsilon_est
    else: 
        var_in = np.linspace(varepsilon_est-3*err_varepsilon,varepsilon_est+3*err_varepsilon,11)

    C = [np.sum(f.residuals_reduced_K_full_lapack(D_est,beta_est,varepsilon, bg, cs, yq, dim_y)**2) for varepsilon in var_in] 
    

    if  logspace==True:
        plt.plot(var_in / varepsilon_est, np.array(C)/Cmin,linewidth=3)
        plt.xscale('log')
        #plt.xlabel(r"Photobleaching loss-rate/frame [$\varepsilon / \varepsilon_{\text{est}}$]")
        #plt.ylabel(r"Cost $[C/C_{min}]$")
        plt.title('Cost Function photobleaching(log)')
    else: 
        plt.plot(var_in, np.array(C)*norm_factor[1]**2,linewidth=3)
        #plt.xlabel(r"Photobleaching loss-rate/frame")
        #plt.ylabel(r"Cost $[A.U.]$")
        plt.title('Cost Function Photobleaching')

    plt.grid()



"""

This script preprocesses data vectors coming main.py

"""


#IMPORT PACKAGES
###############################################################################################################################
###############################################################################################################################
import numpy as np
from scipy.special import erf
import random as rd
import scipy
from scipy import special
from scipy import optimize
import matplotlib.pyplot as plt
import time
from scipy.optimize import NonlinearConstraint,curve_fit
from csv import writer
import numpy as np
import random as rd
import scipy
from scipy import special
from scipy import optimize
import time
from scipy.optimize import NonlinearConstraint
from scipy.linalg import solve
from csv import writer
from scipy.fft import fft,ifft,fft2,ifft2
import pandas as pd
from scipy.stats import kstest
from opt_einsum import contract
import functions as f
import matplotlib.gridspec as gridspec


 

def compute_preprocessing(input):
    
    """
    The objective of this function is to prepare data for HiFRAP analysis. 
    After a rough normalisation to have signal values approximately between 0 and 1, we compute if possible the background value  and the photocleaching decay rate from extra ROIs. 
    Then, data are compressed according to the Fourier compression.
    """

    data_bg,data_ctrl,data_roi,nqc,back,photobleaching,model,dimension,prebleaching,control,time_step,pixel_size,output_dir,kol_test,allGraphs,experiment_name,default_ip,user_initial_guess = input



    #NORMALISATION (to have values betwenen 0 and 1):
    shift = np.min(data_roi) * 1.2
    amp = (np.max(data_roi)-shift) * 0.8
    data_roi = (data_roi - shift) / amp
    data_ctrl = (data_ctrl - shift) / amp
    data_bg =  (data_bg - shift) / amp
    norm_factor = np.array([shift,amp]) #store the normalisation factor



    #background estimation   
    bg0 = np.nan
    if back == 1:
        bg0=np.mean(data_bg)
    


    #stationary intensity estimation
    cs = np.nan
    if prebleaching > 0:
        cs = np.mean(data_roi[:prebleaching,:,:])
        if back == 1:
            cs = cs - bg0
 

    
    #photobleaching estimation 
    varepsilon0 = np.nan
    if photobleaching == 0: #if no photobleaching -> varepsilon = 0
        varepsilon0 = 0 ; control = 1;  #-> varepsilon = 0 -> control=1 (I know photobleaching)
    else:
        #estimation of the photobleaching from a control area
        if control == 1:
            yc = (np.mean(data_ctrl[:,:,:],(1,2)))

         
            
            #FIT CONTROL AREA
            ####################################################################################
            if back == 1:
                def exponential_fit(x,a,b):
                    return a * np.exp( - b * x) + np.mean(data_bg) 
            if back == 0:
                def exponential_fit(x,a,b,c):
                    return a * np.exp( - b * x) + c 

            # Assuming x represents the time points
            x = np.arange(0,len(yc))
            # Fit the data to the exponential function
            yc = yc 
            if back == 1: 
                p0 = [1, 0.001]  # Initial guess for parameters a and b
                bounds = ([0,0], [1000, 1/len(yc) * 1000])  # Bounds for parameters a and b
            if back == 0: 
                p0 = [1, 0.001,0]  # Initial guess for parameters a and b
                bounds = ([0,0,-1000], [1000, 1/len(yc) * 1000,1000])  # Bounds for parameters a and b
            # Perform the curve fit
            params, covariance = curve_fit(exponential_fit, x, yc, p0=p0, bounds=bounds)
            perr = np.sqrt(np.diag(covariance))
            # Extract the fitted parameters
            varepsilon0 = params [1]
            fitted_yc = exponential_fit(x, *params)  # Compute fitted values
            # Plot the data and fitted curve
            #plt.scatter(x, yc, label="Original Data", color="red")
            #plt.plot(x, fitted_yc, label="Exponential Fit", color="blue")
            #plt.show()
            ####################################################################################
        
    
    #RECOVERY DATA AND COMPRESSION
    y=data_roi[prebleaching:,:,:]
    nt, _, nx = y.shape          
    
    #get rid of  one axis if 1D 
    if dimension==1:
        y = y[:,0,:]
    

    #collect all the information  about problem dimension in one list
    dim_y = model,dimension,back,photobleaching,control,prebleaching,nt,nx,nqc,time_step,pixel_size

    #compressing
    yq=f.fourier_compression(y,dim_y)



    return y,yq,varepsilon0,bg0,cs,dim_y,norm_factor,output_dir,kol_test,allGraphs,experiment_name,default_ip,user_initial_guess
           








